# Wolverine (PS5, i38) texture -> Marvel's Spider-Man 2 (PC, i30) texture.
import struct, os
import wtex
BB = wtex.BLOCK_BYTES
SM2_TEXTURE = 0x3E7886C8
HEADER_TAG = 0x4EDE3593

def _stg(data):
    if data[:3] == b'STG':
        flags, hs, ms = struct.unpack_from('<3I', data, 4)
        p = 16; hdr = data[p:p + hs]; p = (p + hs + 15) & ~15; meta = data[p:p + ms]; p = (p + ms + 15) & ~15
        return hdr, meta, data[p:]
    i = data.find(b'1TAD', 0, 1 << 16)
    return None, None, data[max(i, 0):]

def parse_wolverine(data):
    _, _, d = _stg(data)
    _, atype, dsize, count = struct.unpack_from('<4sIIH', d, 0)
    h = None
    for k in range(count):
        tag, off, size = struct.unpack_from('<3I', d, 16 + 12 * k)
        if tag == HEADER_TAG: h = d[off:off + size]
    if h is None or atype == SM2_TEXTURE: return None
    sd_len, hd_len, hw, hh, sw, sh, layers = struct.unpack_from('<IIHHHHH', h, 0)
    return dict(sd_len=sd_len, hd_len=hd_len, hw=hw, hh=hh, sw=sw, sh=sh, layers=layers, kind=h[18], kind2=h[19],
                fmt=struct.unpack_from('<H', h, 20)[0], sd_mips=h[22], hd_mips=h[23], sd=d[dsize:dsize + sd_len])

def _layout(w, h, levels, bpb):
    unit_w = 16 if bpb == 16 else 32
    info = []
    for i in range(levels):
        mw, mh = max(w >> i, 1), max(h >> i, 1); wb, hb = (mw + 3) // 4, (mh + 3) // 4
        info.append((wb, hb, ((wb + unit_w - 1) // unit_w) * ((hb + 15) // 16) * 4096,
                     levels > 1 and wb * hb * bpb <= 2048 and wb < unit_w))
    return info

def ps5_mips(stream, w, h, levels, bpb):
    info = _layout(w, h, levels, bpb)
    if bpb not in wtex._ORDERS: wtex._ORDERS[bpb] = wtex._tile_order(bpb)
    order = wtex._ORDERS[bpb]
    out = [None] * levels
    off = 4096 if any(t for *_, t in info) else 0
    for i in range(levels - 1, -1, -1):
        wb, hb, stored, t = info[i]
        if t: continue
        out[i] = wtex._untile(stream[off:off + stored], wb, hb, bpb); off += stored
    slot = 0
    for i in range(levels):
        wb, hb, stored, t = info[i]
        if not t: continue
        start = wtex.TAIL_SLOTS[slot]; slot += 1
        out[i] = b''.join(b''.join(stream[start + order[y * 16 + x] * bpb:start + (order[y * 16 + x] + 1) * bpb]
                                   for x in range(wb)) for y in range(hb))
    return out

def mips_of(texdata, hddata):
    f = parse_wolverine(texdata)
    if f is None: raise ValueError('not a Wolverine texture')
    if f['layers'] != 1: raise ValueError('texture arrays are not converted')
    if f['fmt'] not in BB: raise ValueError('pixel format %d not supported' % f['fmt'])
    bpb = BB[f['fmt']]
    have_hd = hddata is not None and f['hd_len'] > 0 and len(hddata) >= f['hd_len']
    stream = f['sd'] + (bytes(hddata[:f['hd_len']]) if have_hd else b'')
    if have_hd: w, h, levels = f['hw'], f['hh'], f['sd_mips'] + f['hd_mips']
    else: w, h, levels = f['sw'], f['sh'], f['sd_mips']
    return f, w, h, ps5_mips(stream, w, h, levels, bpb)

def load_templates(folder):
    """SM2 textures (STG) by pixel format: (asset header, meta, header section) of a real one."""
    t = {}
    folders = [f for f in (folder or '').split(';') if f and os.path.isdir(f)]
    for root, _, files in (w for f in folders for w in os.walk(f)):
        for n in files:
            if '.texture' not in n.lower() or n.endswith('.1'): continue
            try:
                data = open(os.path.join(root, n), 'rb').read()
                hdr, meta, d = _stg(data)
                if hdr is None or struct.unpack_from('<I', hdr, 0)[0] != SM2_TEXTURE: continue
                sec = d[48:80]
                key = (sec[24], sec[18])
                t.setdefault(key, (hdr, meta, sec)); t.setdefault((sec[24], None), (hdr, meta, sec))
            except Exception:
                pass
    return t

SD_MAX = 256

def _codecs():
    import sys
    v = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'vendor')
    if os.path.isdir(v) and v not in sys.path: sys.path.append(v)
    import texture2ddecoder, etcpak
    return texture2ddecoder, etcpak

def _repack_gloss_147(f, w, h, mips):
    """Gloss maps of kind 147 keep gloss in red and specular in green (no alpha). The Spider-Man 2 suit shader reads the
    kind-148 layout: specular colour in RGB, gloss in alpha. Repacks every mip and re-encodes it as BC7."""
    import numpy as np
    T, E = _codecs()
    dec = {71: T.decode_bc1, 72: T.decode_bc1, 98: T.decode_bc7, 99: T.decode_bc7, 77: T.decode_bc3, 78: T.decode_bc3}[f['fmt']]
    out = []
    for i, m in enumerate(mips):
        mw, mh = max(w >> i, 1), max(h >> i, 1)
        pw, ph = max(4, (mw + 3) // 4 * 4), max(4, (mh + 3) // 4 * 4)
        a = np.frombuffer(dec(bytes(m), pw, ph), np.uint8).reshape(ph, pw, 4)[..., [2, 1, 0, 3]].astype(np.float32) / 255
        r = a[..., 0]
        gloss = np.where(r <= 0.04045, r / 12.92, ((r + 0.055) / 1.055) ** 2.4)      # red was read through sRGB decoding
        rgba = np.empty((ph, pw, 4), np.uint8)
        rgba[..., 0] = rgba[..., 1] = rgba[..., 2] = (a[..., 1] * 255 + 0.5).astype(np.uint8)
        rgba[..., 3] = (np.clip(gloss, 0, 1) * 255 + 0.5).astype(np.uint8)
        out.append(E.compress_bc7(rgba.tobytes(), pw, ph))
    return out

def to_sm2(texdata, hddata, templates=None):
    """Returns (span0 STG bytes, span1 bytes or None, description)."""
    f, w, h, mips = mips_of(texdata, hddata)
    if f['kind'] == 147 and f['fmt'] in (71, 72, 77, 78, 98, 99):
        try:
            mips = _repack_gloss_147(f, w, h, mips)
            s0, s1, desc = build(mips, w, h, 99, 148, templates)
            return s0, s1, desc + ' (gloss repacked: specular in RGB, gloss in alpha)'
        except ImportError:
            pass                                  # no codecs: convert as it is
    fmt = f['fmt']
    return build(mips, w, h, fmt, f['kind'], templates)

def build(mips, w, h, fmt, kind, templates=None):
    """SM2 texture from mip images (largest first, block-compressed bytes). Returns (span0 STG, span1 or None, description)."""
    # SM2 keeps mips of 256 px and smaller in the main asset and bigger ones in the HD asset, both largest first
    # (checked against real Spider-Man 2 textures: the HD part starts with the full-size image)
    first_sd = 0
    while first_sd < len(mips) - 1 and max(w >> first_sd, h >> first_sd) > SD_MAX: first_sd += 1
    hd = mips[:first_sd]; sd = mips[first_sd:]
    hd_bytes = b''.join(hd)
    sd_bytes = b''.join(sd)
    sw, sh = max(w >> first_sd, 1), max(h >> first_sd, 1)
    f = {'kind': kind}
    tpl = (templates or {}).get((fmt, f['kind'])) or (templates or {}).get((fmt, None))
    sec = bytearray(32)
    struct.pack_into('<IIHHHHH', sec, 0, len(sd_bytes), len(hd_bytes), w if hd else sw, h if hd else sh, sw, sh, 1)
    sec[18] = f['kind']; sec[19] = tpl[2][19] if tpl and tpl[2][18] == f['kind'] else 0
    sec[24] = fmt & 0xFF; sec[25] = tpl[2][25] if tpl else (0x80 if fmt in (72, 83) else 0)
    sec[26] = len(sd); sec[27] = len(hd); sec[28:32] = b'\x01\x01\x01\x01'
    dat1 = bytearray(b'1TAD' + struct.pack('<IIHH', SM2_TEXTURE, 0x50, 1, 0))
    dat1 += struct.pack('<3I', HEADER_TAG, 48, 32)
    dat1 += b'Texture Built File'; dat1 += b'\x00' * (48 - len(dat1)); dat1 += sec
    assert len(dat1) == 0x50
    raw = bytes(dat1) + sd_bytes
    flags_a, b = (0, 0x10000000)
    if tpl:
        a0, b = struct.unpack_from('<II', tpl[0], 8); flags_a = a0 & 0xC0000000
    hdr = struct.pack('<IBBH', SM2_TEXTURE, 0, 2, 0) + struct.pack('<II', flags_a | 0x50, b) + struct.pack('<II', flags_a | len(sd_bytes), b)
    meta = bytearray(tpl[1]) if tpl else bytearray(0x48)
    if not tpl: meta[0] = 3
    struct.pack_into('<I', meta, 16, w if hd else sw); struct.pack_into('<I', meta, 24, h if hd else sh)
    struct.pack_into('<I', meta, 28, 1); struct.pack_into('<I', meta, 32, len(mips)); struct.pack_into('<I', meta, 36, fmt)
    struct.pack_into('<I', meta, 40, 1)
    struct.pack_into('<III', meta, 52, 0x4000, len(sd_bytes) + len(hd_bytes), len(hd_bytes))
    meta[64] = len(hd); meta[65] = len(sd)
    def stg(header, meta_, body):
        out = bytearray(b'STG\x00' + struct.pack('<III', 3, len(header), len(meta_)))
        out += header; out += b'\x00' * (-len(out) % 16); out += meta_; out += b'\x00' * (-len(out) % 16)
        return bytes(out) + body
    desc = '%dx%d %s, %d mips (%d HD)' % (w, h, wtex.FORMAT_NAMES.get(fmt, fmt), len(mips), len(hd))
    return stg(hdr, bytes(meta), raw), (hd_bytes if hd else None), desc


# ------------------------------------------------------------------ flat stand-in textures
def _bc7_constant_block(r, g, b, a):
    """One BC7 mode-6 block of a single colour."""
    bits = 1 << 6; pos = 7
    def put(v, n):
        nonlocal bits, pos
        bits |= (v & ((1 << n) - 1)) << pos; pos += n
    for c in (r, g, b, a):
        put(c >> 1, 7); put(c >> 1, 7)
    p = r & 1                     # one p-bit for both endpoints (the low bit is shared by all channels)
    put(p, 1); put(p, 1)
    return bits.to_bytes(16, 'little')

def constant(fmt, kind, rgba, size=256, templates=None):
    """A single-colour SM2 texture (size x size, mips down to 8 px). fmt: 71/72 BC1, 83 BC5, 98/99 BC7."""
    r, g, b, a = rgba
    if fmt in (71, 72):
        c = ((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3)
        block = struct.pack('<HHI', c, c, 0)
    elif fmt == 83:
        block = bytes([r, r, 0, 0, 0, 0, 0, 0, g, g, 0, 0, 0, 0, 0, 0])
    elif fmt in (98, 99):
        block = _bc7_constant_block(r, g, b, a)
    else:
        raise ValueError('format %d' % fmt)
    mips = []
    s = size
    while s >= 8:
        n = ((s + 3) // 4) ** 2; mips.append(block * n); s //= 2
    return build(mips, size, size, fmt, kind, templates)
