# wolverine_to_sm2.py - turn a Marvel's Wolverine (PS5) suit folder into Spider-Man 2 (PC) suit files.
# Run inside Blender 5.x (it uses the Luna Engine IO Tools add-on to read and write models):
#   blender -b --factory-startup --python wolverine_to_sm2.py -- --suit DIR --out DIR --luna DIR --peter MODEL [--miles MODEL]
#                                                            [--sm2-textures DIR] [--id SUIT_ID]
# Output: OUT\<id>_peter\0\<asset path>, 1\<asset path> (and the same for miles), the layout SuitExporter packs.
import sys, os, re, json, struct, argparse, traceback
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import bpy
from mathutils import Vector, Matrix
import model_to_blender as M2B
import sm2tex
import sm2mat
import wmat
import wgame
import hairconv

LOG = []
def log(*a):
    s = ' '.join(str(x) for x in a); LOG.append(s); print('[sm2] ' + s, flush=True)

ap = argparse.ArgumentParser()
ap.add_argument('--suit', required=True); ap.add_argument('--out', required=True); ap.add_argument('--luna', required=True)
ap.add_argument('--peter'); ap.add_argument('--miles'); ap.add_argument('--sm2-textures'); ap.add_argument('--id')
ap.add_argument('--no-textures', action='store_true')
ap.add_argument('--heads', choices=['auto', 'keep', 'skip'], default='auto', help='head models: auto = left out only for Logan\'s own suits (his face sits under the mask)')
ap.add_argument('--wolverine-game', help='Marvel\'s Wolverine game folder (PPSA03671-app0): textures and materials the suit folder lacks are read from it')
ap.add_argument('--hair-donor', help='a Spider-Man 2 model with strand hair (e.g. boss_kraven.model): its strand settings are used for converted hair')
ap.add_argument('--hair-colour', help='hair colour for converted hair, #rrggbb (Wolverine picks it from a palette this tool cannot read)')
ap.add_argument('--extracted', action='append', default=[], help='a folder of extracted Wolverine assets laid out by asset path (read before the game folder)')
ap.add_argument('--sm2-material', help='a Spider-Man 2 suit material (hero_spiderman_suit_ggx) to build the converted materials on')
A = ap.parse_args(sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else [])

luna_parent, luna_name = os.path.split(os.path.normpath(A.luna))
sys.path.insert(0, luna_parent)
L = __import__(luna_name)
try: L.register()
except Exception: pass
from importlib import import_module
EXP = import_module(luna_name + '.model_export')

suit_dir = os.path.normpath(A.suit)
suit_id = A.id or os.path.basename(suit_dir).lower()
work = os.path.join(A.out, '_work_' + suit_id); os.makedirs(work, exist_ok=True)

def asset_dir():
    # characters\hero\<suit>\... for files from an extracted folder that mirrors the game path
    p = suit_dir.replace('/', '\\').lower()
    i = p.rfind('\\characters\\')
    if i >= 0: return p[i + 1:]
    i = p.find('\\hero\\')
    return 'characters' + p[i:] if i >= 0 else 'characters\\hero\\' + suit_id

BASE = asset_dir().replace('\\', '/')

# ------------------------------------------------------------------ find files
models, textures, wmaterials = {}, [], {}
for root, _, files in os.walk(suit_dir):
    for n in files:
        low = n.lower(); full = os.path.join(root, n)
        if low.endswith('.blender.model') or low.endswith('.suit'): continue
        k = M2B.pair_key(n)
        if k:
            models.setdefault(os.path.join(root, k[0]), {})[k[1]] = full
        elif low.endswith('.model'):
            models.setdefault(full, {})[0] = full
        elif low.endswith('.texture') and not low.endswith('.hd.texture'):
            textures.append(full)
        elif low.endswith('.material'):
            wmaterials.setdefault(low, full)

# ------------------------------------------------------------------ models -> importable copies
bpy.ops.wm.read_factory_settings(use_empty=True)
try: L.register()
except Exception: pass

def imp(p):
    before = set(bpy.data.objects)
    bpy.ops.import_scene.engine_model(filepath=p, import_all_lods=False, import_shape_keys=False)
    new = [o for o in bpy.data.objects if o not in before]
    arms = [o for o in new if o.type == 'ARMATURE']
    return (arms[0] if arms else None), [o for o in new if o.type == 'MESH'], new

parts = []; used_mats = set()
low_suit = suit_dir.replace('\\', '/').lower()
logan_suit = any(w in low_suit for w in ('hero_wolverine', 'hero_logan')) or any('mask' in os.path.basename(k).lower() for k in models)
skip_heads = A.heads == 'skip' or (A.heads == 'auto' and logan_suit)
log('heads: %s' % ('left out (Logan\'s face sits under the mask)' if skip_heads else 'kept (this character\'s own face)'))
stems = {os.path.normcase(k): k for k in models}
has_parts = any(('luna_assets' in k.replace('\\', '/').lower() or 'ubermodel' in k.replace('\\', '/').lower()) for k in models)
def variant_of(stem):
    # name_civ1 / name_teamx / ... next to name: an alternative version, not an extra part
    d, n = os.path.split(stem); n = n[:-len('.model')]
    while '_' in n:
        n = n.rsplit('_', 1)[0]
        if os.path.normcase(os.path.join(d, n + '.model')) in stems: return n + '.model'
    return None
for stem, halves in sorted(models.items()):
    name = os.path.basename(stem); lname = name.lower()
    if re.search(r'(^|_)head\d*\.model$', lname) and skip_heads:
        log('skip  %s  (Logan\'s face; the suit uses the mask)' % name); continue
    if re.search(r'_skeleton\.model$|^collision_|pose_art|_art\.model$', lname):
        log('skip  %s  (skeleton display, collision or posed art model)' % name); continue
    v = variant_of(stem)
    if v and not re.search(r'(^|_)head\d*\.model$', lname):
        log('skip  %s  (an alternative version of %s)' % (name, v)); continue
    folder_name = os.path.basename(os.path.dirname(stem)).lower()
    if has_parts and lname == folder_name + '.model' and 'luna_assets' not in stem.replace('\\', '/').lower():
        log('skip  %s  (the whole character in one model; the separate parts are used instead)' % name); continue
    try:
        p0 = open(halves[0], 'rb').read() if 0 in halves else None
        p1 = open(halves[1], 'rb').read() if 1 in halves else None
        if p0 is None: log('skip  %s  (only the streamed half is here)' % name); continue
        data, info = M2B.convert(p0, p1)
        path = os.path.join(work, re.sub(r'\.model$', '', name) + '.blender.model')
        open(path, 'wb').write(data)
        arm, meshes, new = imp(path)
        nb = len(arm.data.bones) if arm else 0
        if nb:
            for o in meshes:
                for sl in o.material_slots:
                    if sl.material:
                        mp = EXP._material_asset_path_from_blender(sl.material).replace('\\', '/')
                        if mp: used_mats.add(mp)
        for o in new: bpy.data.objects.remove(o, do_unlink=True)
        if nb == 0:
            log('skip  %s  (no skeleton: an art reference, not a wearable part)' % name); continue
        parts.append(path); log('part  %s  (%d meshes, %d bones)' % (name, len(meshes), nb))
    except Exception as e:
        log('FAIL  %s: %s' % (name, e))

# ------------------------------------------------------------------ textures
tex_assets = []
if not A.no_textures:
    T = sm2tex.load_templates(A.sm2_textures)
    for t in sorted(textures):
        n = os.path.basename(t)
        hd = t[:-len('.texture')] + '.hd.texture'
        try:
            s0, s1, desc = sm2tex.to_sm2(open(t, 'rb').read(), open(hd, 'rb').read() if os.path.isfile(hd) else None, T)
            rel = os.path.relpath(t, suit_dir).replace('\\', '/')
            tex_assets.append((BASE + '/' + rel, s0, s1)); log('tex   %s  %s' % (n, desc))
        except Exception as e:
            log('skip  texture %s: %s' % (n, e))

# ------------------------------------------------------------------ materials: Spider-Man 2 suit materials on the converted textures
sm2_mats = {}          # Wolverine material file name (lower) -> (Spider-Man 2 material asset path, bytes)
mat_graph = {}         # Wolverine material file name (lower) -> its shader graph path
hair_mats = {}         # hair-card materials (lower name) -> parsed Wolverine material
DONOR = None
if A.hair_donor and os.path.isfile(A.hair_donor):
    try:
        _dn, DONOR = hairconv.pick_donor(hairconv.donor_descriptions(A.hair_donor))
        if DONOR: log('hair donor  %s  (strand settings of %s)' % (os.path.basename(A.hair_donor), _dn))
        else: log('hair donor %s has no strand hair' % os.path.basename(A.hair_donor))
    except Exception as e:
        log('hair donor not used: %s' % e); DONOR = None
if A.sm2_material and os.path.isfile(A.sm2_material) and tex_assets:
    try:
        TPL = sm2mat.Template(open(A.sm2_material, 'rb').read())
        log('material template  %s  (%s)' % (os.path.basename(A.sm2_material), TPL.graph.replace('\\', '/').rsplit('/', 1)[-1]))
        by_name = {}
        for rel, s0, s1 in tex_assets: by_name.setdefault(rel.rsplit('/', 1)[-1].lower(), rel)
        T = sm2tex.load_templates(A.sm2_textures)
        extra = {}
        def standin(key, fmt, kind, rgba):
            if key not in extra:
                rel = '%s/textures/%s_sm2_%s.texture' % (BASE, suit_id, key)
                s0, s1, desc = sm2tex.constant(fmt, kind, rgba, templates=T)
                tex_assets.append((rel, s0, s1)); extra[key] = rel; log('tex   %s  (made here: %s)' % (rel.rsplit('/', 1)[-1], desc))
            return extra[key]
        GAME = None
        _readers = []
        for _ex in A.extracted:
            try: _readers.append(wgame.ExtractedFolder(_ex)); log('extracted assets  %s' % _ex)
            except OSError as e: log('extracted folder not used: %s' % e)
        if A.wolverine_game:
            try: _readers.append(wgame.GameFolder(A.wolverine_game)); log('game folder  %s' % A.wolverine_game)
            except OSError as e: log('game folder not used: %s' % e)
        if _readers: GAME = wgame.Sources(_readers)
        # materials the parts use but the folder lacks (Logan's skin under the suit, shared parts): from the game
        sources = dict((low, ('file', full)) for low, full in wmaterials.items())
        for mp in sorted(used_mats):
            low = mp.rsplit('/', 1)[-1].lower()
            if low not in sources and GAME is not None:
                data = GAME.read(mp, 0)
                if data: sources[low] = ('game', mp, data)
        def from_game(tpath):
            # a texture the material names that is not in the folder: convert it from the game's own copy
            if GAME is None: return None
            s0d = GAME.read(tpath, 0)
            if not s0d: return None
            try:
                s0, s1, desc = sm2tex.to_sm2(s0d, GAME.read(tpath, 1), T)
            except Exception as e:
                log('skip  texture %s from the game: %s' % (tpath.rsplit('/', 1)[-1], e)); return None
            rel = tpath.replace('\\', '/')
            tex_assets.append((rel, s0, s1)); by_name[rel.rsplit('/', 1)[-1].lower()] = rel
            log('tex   %s  %s  (from the extracted / game files)' % (rel.rsplit('/', 1)[-1], desc))
            return rel
        tex_files = {os.path.basename(t).lower(): t for t in textures}
        def load_wtex(tpath):
            n = tpath.replace('\\', '/').rsplit('/', 1)[-1].lower()
            if n in tex_files:
                f = tex_files[n]; hd = f[:-len('.texture')] + '.hd.texture'
                return open(f, 'rb').read(), (open(hd, 'rb').read() if os.path.isfile(hd) else None)
            if GAME is not None:
                d0 = GAME.read(tpath, 0)
                if d0: return d0, GAME.read(tpath, 1)
            return None, None
        for low, src in sorted(sources.items()):
            full = src[1]
            try: parsed = wmat.parse(open(full, 'rb').read() if src[0] == 'file' else src[2])
            except wmat.MaterialError as e: log('skip  material %s: %s' % (os.path.basename(full), e)); continue
            mat_graph[low] = parsed['graph'].lower()
            if 'hair' in mat_graph[low] and 'wrapmesh' not in mat_graph[low]:
                hair_mats[low] = parsed
                log('mat   %s: hair cards -> %s' % (os.path.basename(full.replace('\\', '/')),
                    'Spider-Man 2 strand hair' if DONOR else 'left out (no hair donor model set, see --hair-donor)')); continue
            chosen, _ = wmat.roles(parsed)
            found = {r: by_name.get(p.rsplit('/', 1)[-1].lower()) or from_game(p) for r, p in chosen.items() if r in ('color', 'normal', 'gloss')}
            if not found.get('color'):
                log('mat   %s: no converted colour texture; the template suit\'s material is used' % os.path.basename(full)); continue
            rep = {sm2mat.SLOT_COLOR: found['color'],
                   sm2mat.SLOT_NORMAL: found.get('normal') or standin('flat_n', 83, 18, (128, 128, 0, 255)),
                   sm2mat.SLOT_GLOSS: found.get('gloss') or standin('neutral_g', 99, 148, (57, 57, 57, 77)),
                   sm2mat.SLOT_DETAIL_MASK: standin('no_detail_detailmask', 71, 16, (0, 0, 0, 255))}
            path = '%s/materials/%s' % (BASE, os.path.basename(full.replace('\\', '/')).lower())
            sm2_mats[low] = (path, TPL.build(rep))
            log('mat   %s%s -> %s  (colour %s, normal %s, gloss %s)' % (os.path.basename(full.replace('\\', '/')), ' (from the game)' if src[0] == 'game' else '', path.rsplit('/', 1)[-1],
                rep[sm2mat.SLOT_COLOR].rsplit('/', 1)[-1], rep[sm2mat.SLOT_NORMAL].rsplit('/', 1)[-1], rep[sm2mat.SLOT_GLOSS].rsplit('/', 1)[-1]))
    except Exception as e:
        log('FAIL  materials: %s (the template suit\'s materials are used instead)' % e); sm2_mats = {}
elif not A.sm2_material:
    log('no Spider-Man 2 material template given: the template suit\'s materials are used')

# ------------------------------------------------------------------ re-rig onto a Spider-Man 2 skeleton
EXTRA = {'neck01': 'neck', 'neck02': 'neck', 'neck03': 'head', 'FACIAL_jaw': 'jaw', 'FACIAL_jaw_driven': 'jaw',
         'LF_toe': 'LF_ball', 'RT_toe': 'RT_ball', 'LF_glute': 'LF_upperButtock_miles', 'RT_glute': 'RT_upperButtock_miles',
         'LF_upleg_bind_3': 'LF_upleg_bind_2', 'RT_upleg_bind_3': 'RT_upleg_bind_2', 'LF_upleg_bind_4': 'LF_uplegTwist',
         'RT_upleg_bind_4': 'RT_uplegTwist', 'LF_upleg_bind_5': 'LF_uplegTwist', 'RT_upleg_bind_5': 'RT_uplegTwist',
         'LF_uparm_bind_5': 'LF_uparm_bind_4', 'RT_uparm_bind_5': 'RT_uparm_bind_4', 'LF_loarm_bind_1': 'LF_loarm_bind_2',
         'RT_loarm_bind_1': 'RT_loarm_bind_2', 'motionJoint': 'a_body', 'footIK_root': 'ground'}
for s in ('LF', 'RT'):
    for f in 'ABCD': EXTRA['%s_finger_%s_end' % (s, f)] = '%s_finger_%s_D' % (s, f)
    EXTRA[s + '_thumb_end'] = s + '_thumb_C'

# Wolverine material name -> words to look for in the template's material names, in order
MATWORDS = [('torso', ['red', 'torso', 'chest', 'body']), ('legs', ['blue_a', 'legs', 'leg', 'pants']),
            ('boot', ['blue_b', 'legs', 'boot', 'leg']), ('glove', ['armor', 'gloves', 'glove', 'gauntlet', 'hand']),
            ('mask', ['head', 'mask']), ('scalp', ['head', 'mask']), ('eye', ['eye_lense', 'eye', 'lens']),
            ('claw', ['trim', 'frames', 'armor']), ('belt', ['trim', 'armor']),
            ('logan', ['white_carbonfiber', 'fabric', 'torso', 'red', 'body'])]

def matpath(m): return EXP._material_asset_path_from_blender(m)

def pick_material(wname, tmats):
    low = wname.lower()
    for key, words in MATWORDS:
        if key in low:
            for w in words:
                for p, m in tmats:
                    if w in p.lower().rsplit('\\', 1)[-1]: return p, m
    for w in ['red', 'torso', 'body', 'fabric', 'suit']:
        for p, m in tmats:
            if w in p.lower().rsplit('\\', 1)[-1]: return p, m
    return tmats[0]

def load_wtex_any(tpath):
    try: return load_wtex(tpath)
    except NameError: return None, None

def hair_colour_for(obj, part, parsed):
    """Hair colour: the average of the character's solid hair layer (same part, non-card material with a colour
    texture) when there is one, otherwise the hair material's own colour."""
    try:
        for o in bpy.data.objects:
            if o.type != 'MESH' or o is obj: continue
            for sl in o.material_slots:
                if not sl.material: continue
                low = matpath(sl.material).replace('\\', '/').rsplit('/', 1)[-1].lower()
                if 'hair' not in low or low in hair_mats or low not in sm2_mats: continue
                p = wmat.parse(open(wmaterials[low], 'rb').read()) if low in wmaterials else None
                if not p: continue
                ch, _ = wmat.roles(p)
                if 'color' not in ch: continue
                img = hairconv.texture_map(*load_wtex_any(ch['color']))
                if img is None: continue
                srgb = img[..., :3].reshape(-1, 3).mean(0)
                lin = [x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in srgb]
                log('  hair colour from %s: %.3f %.3f %.3f' % (low, *lin))
                return lin
    except Exception as e:
        log('  hair colour: %s' % e)
    c = wmat.hair_color(parsed) or wmat.DEFAULT_HAIR_COLOR
    log('  hair colour from the hair material: %.3f %.3f %.3f' % tuple(c))
    return c

def convert_for(hero, template):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    try: L.register()
    except Exception: pass
    parm, pmeshes, _ = imp(template)
    pbones = parm.data.bones
    tmats = []
    for m in pmeshes:
        for s in m.material_slots:
            if s.material and all(s.material is not x[1] for x in tmats): tmats.append((matpath(s.material), s.material))
    body_like = [x for x in tmats if not any(w in x[0].lower() for w in ('knife', 'prop_', 'dmg_decal', 'webshooter', 'shooter'))]
    for m in pmeshes:
        paths = [matpath(s.material).lower() for s in m.material_slots if s.material]
        if not any('prop_' in p or 'knife' in p for p in paths):
            bpy.data.objects.remove(m, do_unlink=True)

    def target(b):
        while b is not None:
            n = EXTRA.get(b.name, b.name)
            if n in pbones: return n
            b = b.parent
        return pbones[0].name

    new_objs = []; hair_objs = []
    for part in parts:
        warm, wmeshes, _ = imp(part)
        wb = warm.data.bones
        Mx = {}
        for b in wb:
            t = target(b); pb = pbones[t]
            if EXTRA.get(b.name, b.name) != t: Mx[b.name] = None; continue
            wh, wt = warm.matrix_world @ b.head_local, warm.matrix_world @ b.tail_local
            ph, pt = parm.matrix_world @ pb.head_local, parm.matrix_world @ pb.tail_local
            a, c = wt - wh, pt - ph
            ok = a.length > 1e-6 and c.length > 1e-6
            R = a.normalized().rotation_difference(c.normalized()).to_matrix().to_4x4() if ok else Matrix.Identity(4)
            s = max(0.6, min(1.6, c.length / a.length)) if ok else 1.0
            ax = c.normalized() if c.length > 1e-6 else Vector((0, 0, 1))
            S = Matrix.Identity(3) + (s - 1) * Matrix([[ax[i] * ax[j] for j in range(3)] for i in range(3)])
            Mx[b.name] = Matrix.Translation(ph) @ S.to_4x4() @ R @ Matrix.Translation(-wh)
        direct = [b.name for b in wb if Mx[b.name] is not None]
        weighted = set()
        for obj in wmeshes:
            nm = [g.name for g in obj.vertex_groups]
            for v in obj.data.vertices:
                for g in v.groups:
                    if g.weight > 0.01: weighted.add(nm[g.group])
        loose = sorted(n for n in weighted if n in wb and Mx.get(n) is None)
        log('  %s  bones %s: %d of %d match a %s bone%s' % (hero, os.path.basename(part).replace('.blender.model', ''), len(direct), len(wb), hero,
            '; %d skinned bones have no match and follow their parent (%s%s)' % (len(loose), ', '.join(loose[:8]), ', ...' if len(loose) > 8 else '') if loose else '; every skinned bone matches'))
        for b in wb:
            if Mx[b.name] is None:
                p = b.parent
                while p is not None and Mx.get(p.name) is None: p = p.parent
                Mx[b.name] = Mx[p.name] if p is not None else Matrix.Identity(4)
        for obj in list(wmeshes):
            mats_here = [matpath(sl.material).lower() for sl in obj.material_slots if sl.material]
            def is_hair(m_):
                g = mat_graph.get(m_.replace('\\', '/').rsplit('/', 1)[-1], '')
                return 'hair' in g and 'wrapmesh' not in g
            if mats_here and all(is_hair(m_) for m_ in mats_here):
                low_m = mats_here[0].replace('\\', '/').rsplit('/', 1)[-1]
                if DONOR is not None and low_m in hair_mats:
                    hair_objs.append((obj, low_m, part)); continue        # re-rigged with the rest, then turned into strands
                log('  %s  %s: left out (hair cards: %s)' % (hero, obj.name, low_m))
                wmeshes.remove(obj); bpy.data.objects.remove(obj, do_unlink=True); continue
            if mats_here and all(('shared_scalp' in m_ or 'wrapmesh' in m_) for m_ in mats_here):
                # an invisible helper shell in Wolverine (scalp / hair wrap): it would show with a real material here
                log('  %s  %s: left out (invisible helper: %s)' % (hero, obj.name, mats_here[0].replace('\\', '/').rsplit('/', 1)[-1]))
                wmeshes.remove(obj); bpy.data.objects.remove(obj, do_unlink=True); continue
        for obj in wmeshes:
            me = obj.data; names = [g.name for g in obj.vertex_groups]
            mw = obj.matrix_world.copy(); inv = mw.inverted()
            tw = {}
            for i, v in enumerate(me.vertices):
                x = mw @ v.co; acc = Vector((0, 0, 0)); ws = 0.0
                for g in v.groups:
                    n = names[g.group]
                    if n not in wb or g.weight <= 0: continue
                    acc += g.weight * (Mx[n] @ x); ws += g.weight
                    tn = target(wb[n]); d = tw.setdefault(tn, {}); d[i] = d.get(i, 0) + g.weight
                if ws > 0: v.co = inv @ (acc / ws)
            me.update()
            obj.vertex_groups.clear()
            for tn, d in tw.items():
                g = obj.vertex_groups.new(name=tn)
                for i, w in d.items(): g.add([i], w, 'REPLACE')
            for slot in obj.material_slots:
                if not slot.material or any(obj is h[0] for h in hair_objs): continue
                src = matpath(slot.material).replace('/', '\\').split('\\')[-1]
                own = sm2_mats.get(src.lower()) or sm2_mats.get(src.lower() + '.material')
                if own:
                    m = bpy.data.materials.get(own[0]) or bpy.data.materials.new(own[0])
                    try: m.engine_material_path = own[0].replace('/', '\\')
                    except Exception: pass
                    slot.material = m
                    log('  %s  %s: %s -> %s (converted)' % (hero, obj.name, src, own[0].rsplit('/', 1)[-1]))
                    continue
                p, m = pick_material(src, body_like)
                slot.material = m
                log('  %s  %s: %s -> %s' % (hero, obj.name, src, p.rsplit('\\', 1)[-1]))
            for k in list(obj.keys()):
                if k.startswith('engine_subset') or k.startswith('engine_material_index'): del obj[k]
            obj.parent = parm; obj.matrix_world = mw
            for mod in list(obj.modifiers):
                if mod.type == 'ARMATURE': obj.modifiers.remove(mod)
            mod = obj.modifiers.new('Armature', 'ARMATURE'); mod.object = parm
            obj['is_mask_part'] = bool(re.search(r'mask|helmet|cowl|head', os.path.basename(part).lower()))
            new_objs.append(obj)
        bpy.data.objects.remove(warm, do_unlink=True)

    for obj, low_m, part in hair_objs:
        parsed = hair_mats[low_m]
        alpha = root = None
        for slot_, tp in parsed['textures']:
            suf = wmat.suffix_of(tp)
            if suf in ('a', 'x'):
                img = hairconv.texture_map(*load_wtex_any(tp))
                if img is None: continue
                if suf == 'x':
                    root = img
                    if alpha is None: alpha = img
                else: alpha = img
        colour = hair_colour_for(obj, part, parsed)
        if A.hair_colour:
            try:
                hx = A.hair_colour.strip().lstrip('#')
                srgb = [int(hx[i:i + 2], 16) / 255.0 for i in (0, 2, 4)]
                colour = [x / 12.92 if x <= 0.04045 else ((x + 0.055) / 1.055) ** 2.4 for x in srgb]
                log('  hair colour set to #%s' % hx)
            except Exception:
                log('  hair colour %r not understood (use #rrggbb)' % A.hair_colour)
        log('  hair maps: %s' % ', '.join(n for n, m in (('strand coverage', alpha), ('root map', root)) if m is not None) or 'none (strands fill each card evenly)')
        nm = 'HairDescription_' + re.sub(r'[^A-Za-z0-9_]', '_', os.path.basename(part).replace('.blender.model', ''))
        try:
            h = hairconv.build_strands(obj, parm, alpha, root, colour, DONOR, nm, log=log)
        except Exception as e:
            h = None; log('  %s  %s: hair conversion failed (%s); left out' % (hero, obj.name, e))
        if h is None: log('  %s  %s: no strands could be made; left out' % (hero, obj.name))
        if obj in new_objs: new_objs.remove(obj)
        bpy.data.objects.remove(obj, do_unlink=True)
    kept = [o for o in bpy.data.objects if o.type == 'MESH' and o.parent == parm and o not in new_objs]
    old_idx = {int(o['engine_subset_index']): o for o in kept if o.get('engine_subset_index') is not None}
    order = new_objs + kept
    for i, o in enumerate(order):
        o['engine_subset_index'] = i; o['engine_lod_mask'] = 255; o.hide_viewport = False
    newid = {old: order.index(o) for old, o in old_idx.items()}
    body = [i for i, o in enumerate(new_objs) if not o['is_mask_part']]
    mask = [i for i, o in enumerate(new_objs) if o['is_mask_part']]
    looks = []
    for lk in json.loads(parm.get('engine_model_looks_json', '[]')):
        nm = str(lk.get('name', '')).lower()
        ids = body + mask if nm == 'default' else body if nm == 'body' else mask if nm == 'mask' else \
            [newid[x] for x in lk.get('subset_ids', []) if x in newid]
        lk = dict(lk); lk['subset_ids'] = ids; lk['lods'] = [{'start': 0, 'count': len(ids)} for _ in lk.get('lods', [0] * 8)]
        looks.append(lk)
    if not looks or not any(str(l.get('name', '')).lower() == 'default' for l in looks):
        looks.insert(0, {'index': 0, 'name': 'Default', 'subset_ids': body + mask, 'lods': [{'start': 0, 'count': len(body + mask)}] * 8})
    parm['engine_model_looks_json'] = json.dumps(looks); parm['engine_model_looks_modified'] = True

    out_root = os.path.join(A.out, '%s_%s' % (suit_id, hero))
    model_rel = '%s/%s_%s.model' % (BASE, suit_id, hero)
    dst = os.path.join(out_root, '0', *model_rel.split('/'))
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    bpy.context.view_layer.objects.active = parm
    for o in bpy.context.view_layer.objects: o.select_set(o == parm)
    r = bpy.ops.export_scene.engine_model(filepath=dst, stg_mode='STG')
    if r != {'FINISHED'}: raise RuntimeError('model export failed')
    log('%s: model %s  (%d mesh parts on %s\'s skeleton)' % (hero, model_rel, len(new_objs), hero))
    for path, data in sm2_mats.values():
        p0 = os.path.join(out_root, '0', *path.split('/')); os.makedirs(os.path.dirname(p0), exist_ok=True)
        open(p0, 'wb').write(data)
    for rel, s0, s1 in tex_assets:
        p0 = os.path.join(out_root, '0', *rel.split('/')); os.makedirs(os.path.dirname(p0), exist_ok=True)
        open(p0, 'wb').write(s0)
        if s1:
            p1 = os.path.join(out_root, '1', *rel.split('/')); os.makedirs(os.path.dirname(p1), exist_ok=True)
            open(p1, 'wb').write(s1)
    return out_root

ok = 0
if not parts: log('FAIL  no wearable model found in %s' % suit_dir)
else:
    for hero, tpl in (('peter', A.peter), ('miles', A.miles)):
        if not tpl: continue
        try:
            convert_for(hero, tpl); ok += 1
        except Exception as e:
            log('FAIL  %s: %s' % (hero, e)); traceback.print_exc()
os.makedirs(A.out, exist_ok=True)
open(os.path.join(A.out, suit_id + '_convert_log.txt'), 'w', encoding='utf-8').write('\n'.join(LOG) + '\n')
print('[sm2] DONE %d' % ok, flush=True)
sys.exit(0 if ok else 1)
