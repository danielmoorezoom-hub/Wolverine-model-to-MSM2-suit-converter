# Spider-Man 2 (PC) .material writing: a real Spider-Man 2 material used as the template, with its textures swapped.
# Layout (shared with Marvel's Wolverine): STG wrapper -> DAT1 with sections
#   0xE1275683  header (its first 8 bytes are a pointer, fixed up at load, to the material graph path)
#   0xF5260180  overrides: 10 x u32 header, parameter keys + values, flags, texture table (string offset, slot), strings
#   0x77D77983  render state
import struct

SEC_HEADER = 0xE1275683
SEC_OVERRIDES = 0xF5260180
MATERIAL_TYPE = 0x3B180DB4

# texture slots of hero_spiderman_suit_ggx.materialgraph (CRC-32 of the input names)
SLOT_COLOR = 0xABDAD780
SLOT_NORMAL = 0x7AE34E7A
SLOT_GLOSS = 0x6376D191          # specular colour in RGB, gloss in alpha (same layout as Wolverine's _g)
SLOT_DETAIL_MASK = 0x50C487C9    # red / blue pick where the tiling detail maps apply; black = no detail


def _stg(data):
    if data[:3] != b'STG':
        raise ValueError('not an STG file')
    flags, hs, ms = struct.unpack_from('<3I', data, 4)
    p = 16
    hdr = data[p:p + hs]; p = (p + hs + 15) & ~15
    meta = data[p:p + ms]; p = (p + ms + 15) & ~15
    return hdr, meta, data[p:]


class Template:
    def __init__(self, data):
        self.hdr, self.meta, d = _stg(data)
        magic, atype, size, count, fixups = struct.unpack_from('<4sIIHH', d, 0)
        if magic != b'1TAD' or atype != MATERIAL_TYPE:
            raise ValueError('not a Spider-Man 2 material')
        self.d = d[:size]
        self.count, self.fixups = count, fixups
        self.secs = [list(struct.unpack_from('<3I', d, 16 + 12 * k)) for k in range(count)]
        self.fix = [list(struct.unpack_from('<II', d, 16 + 12 * count + 8 * k)) for k in range(fixups)]
        o, s = self.section(SEC_OVERRIDES)
        (self.ov_size, self.nparams, self.values, self.nflags, self.flags, self.ntex, self.tex, self.strings,
         self.u8, self.u9) = struct.unpack_from('<10I', d, o)
        self.textures = []
        for k in range(self.ntex):
            so, slot = struct.unpack_from('<II', d, o + self.tex + 8 * k)
            a = o + self.strings + so
            self.textures.append((slot, d[a:d.index(b'\0', a)].decode('latin1')))
        a = self.fix[0][1] if self.fix else 0
        self.graph = d[a:d.index(b'\0', a)].decode('latin1') if self.fix else ''

    def section(self, tag):
        for t, o, s in self.secs:
            if t == tag:
                return o, s
        raise KeyError('%08X' % tag)

    def build(self, replace):
        """replace: {slot: texture path}. Slots not listed keep the template's texture. Returns STG bytes."""
        d = self.d
        o, s = self.section(SEC_OVERRIDES)
        tex = [(slot, replace.get(slot, path).replace('/', '\\') if slot in replace else path) for slot, path in self.textures]
        # strings: one copy of each path, in table order, as the game's own files do
        strings = bytearray(); where = {}
        table = bytearray()
        for slot, path in tex:
            if path not in where:
                where[path] = len(strings); strings += path.encode('latin1') + b'\0'
            table += struct.pack('<II', where[path], slot)
        body = bytearray(d[o:o + self.tex]) + table
        # the template's strings start right after its table; keep that
        assert self.strings == self.tex + 8 * self.ntex, 'unexpected override layout'
        body += strings
        while len(body) % 16: body += b'\0'
        ov_size = len(body)              # the game's files store the padded size in both places
        struct.pack_into('<I', body, 0, ov_size)
        delta = len(body) - s
        # rebuild the DAT1: sections after the overrides move by delta
        out = bytearray(d[:o]) + body + bytearray(d[o + s:])
        secs = []
        for t, so_, ss in self.secs:
            if t == SEC_OVERRIDES: ss = ov_size
            elif so_ > o: so_ += delta
            secs.append((t, so_, ss))
        for k, (t, so_, ss) in enumerate(secs):
            struct.pack_into('<3I', out, 16 + 12 * k, t, so_, ss)
        for k, (a, b) in enumerate(self.fix):
            struct.pack_into('<II', out, 16 + 12 * self.count + 8 * k, a + (delta if a > o else 0), b + (delta if b > o else 0))
        struct.pack_into('<I', out, 8, len(out))
        # asset header: type, (flags | size, template's second word)
        hdr = bytearray(self.hdr)
        if len(hdr) >= 16:
            a0 = struct.unpack_from('<I', hdr, 8)[0]
            struct.pack_into('<I', hdr, 8, (a0 & 0xC0000000) | len(out))
        stg = bytearray(b'STG\x00' + struct.pack('<III', 1 if not self.meta else 3, len(hdr), len(self.meta)))
        stg += hdr; stg += b'\0' * (-len(stg) % 16)
        if self.meta: stg += self.meta; stg += b'\0' * (-len(stg) % 16)
        return bytes(stg) + bytes(out)
