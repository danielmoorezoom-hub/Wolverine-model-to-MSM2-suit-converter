# Wolverine hair cards -> Spider-Man 2 strand hair.
# Wolverine draws long hair as flat cards with a see-through strand texture. Spider-Man 2 draws hair as strands: curves the
# engine turns into thin ribbons, coloured by a root-to-tip gradient. Each card is sampled into strands running along it
# (the card's texture says where the strands are, where they start and where they thin out), skinned to the same bones.
# The strand settings (clumping, thickness, gloss, simulation) come from a real Spider-Man 2 hair description.
import os, sys, struct, base64, math
HERE = os.path.dirname(os.path.abspath(__file__))
for _v in (os.path.join(HERE, 'vendor'),):
    if os.path.isdir(_v) and _v not in sys.path: sys.path.append(_v)   # after Blender's own packages
import numpy as np

SUBSET_SIZE = 1256; DESC_OFF = 16; DESC_SIZE = 1112
MAX_JOINTS = 12


def _crc32_name(s):
    c = 0xEDB88320
    for b in s.encode():
        c ^= b
        for _ in range(8): c = (c >> 1) ^ 0xEDB88320 if c & 1 else c >> 1
    return c


def donor_descriptions(model_path):
    """{subset name: 1112-byte strand description} from a Spider-Man 2 model with strand hair."""
    d = open(model_path, 'rb').read()
    b = d.find(b'1TAD', 0, 1 << 16)
    if b < 0: return {}
    d = d[b:]
    n = struct.unpack_from('<H', d, 12)[0]
    want = _crc32_name('Model Spline Subsets')
    for i in range(n):
        tag, off, size = struct.unpack_from('<3I', d, 16 + 12 * i)
        if tag != want: continue
        out = {}
        for k in range(size // SUBSET_SIZE):
            base = off + k * SUBSET_SIZE
            name_rel = struct.unpack_from('<I', d, base + 4)[0]
            name = d[name_rel:d.index(b'\0', name_rel)].decode('latin1') if name_rel else 'subset%d' % k
            out[name] = bytes(d[base + DESC_OFF:base + DESC_OFF + DESC_SIZE])
        return out
    return {}


def pick_donor(descs):
    for key in ('furhood', 'hood', 'hair'):
        for n, raw in descs.items():
            if key in n.lower(): return n, raw
    return next(iter(descs.items())) if descs else (None, None)


# ------------------------------------------------------------------ texture maps
def texture_map(data0, data1):
    """RGBA float array (h, w, 4) of a Wolverine texture (largest mip available), or None."""
    try:
        import sm2tex, wtex, texture2ddecoder as T
    except ImportError:
        return None
    try:
        f, w, h, mips = sm2tex.mips_of(data0, data1)
    except Exception:
        return None
    fmt = f['fmt']
    dec = {71: T.decode_bc1, 72: T.decode_bc1, 80: T.decode_bc4, 81: T.decode_bc4, 83: T.decode_bc5, 84: T.decode_bc5,
           98: T.decode_bc7, 99: T.decode_bc7, 77: T.decode_bc3, 78: T.decode_bc3}.get(fmt)
    if dec is None: return None
    # 512 px is plenty to find strands; use the first mip at or below it
    i = 0
    while i < len(mips) - 1 and max(w >> i, h >> i) > 512: i += 1
    mw, mh = max(w >> i, 1), max(h >> i, 1)
    a = np.frombuffer(dec(bytes(mips[i]), mw, mh), np.uint8).reshape(mh, mw, 4)[..., [2, 1, 0, 3]].astype(np.float32) / 255
    if fmt in (80, 81): a[..., 3] = a[..., 0]          # BC4: the single channel is the coverage
    return a


def _sample(img, u, v):
    if img is None: return None
    h, w = img.shape[:2]
    x = int((u % 1.0) * (w - 1)); y = int((v % 1.0) * (h - 1))
    return img[y, x]


# ------------------------------------------------------------------ cards -> strands
def _islands(me):
    """Faces grouped into connected cards (by shared vertices)."""
    parent = list(range(len(me.vertices)))
    def find(x):
        while parent[x] != x: parent[x] = parent[parent[x]]; x = parent[x]
        return x
    for p in me.polygons:
        vs = list(p.vertices)
        for v in vs[1:]:
            a, b = find(vs[0]), find(v)
            if a != b: parent[a] = b
    groups = {}
    for t in me.loop_triangles:
        groups.setdefault(find(me.loops[t.loops[0]].vertex_index), []).append(t)
    return list(groups.values())


def build_strands(obj, arm, alpha_img, root_img, colour, donor_raw, name, log=print, spacing=0.004):
    """Turns the hair-card mesh obj (already on arm's skeleton) into a strand-hair object. Returns it, or None."""
    import bpy, mathutils
    from importlib import import_module
    H = None
    for m in list(sys.modules.values()):
        if getattr(m, '__name__', '').endswith('.model_hair') and hasattr(m, '_description_to_object_props'): H = m
    me = obj.data
    if not me.uv_layers: return None
    me.calc_loop_triangles()
    uvl = me.uv_layers[0].data
    mw = obj.matrix_world; to_arm = arm.matrix_world.inverted() @ mw
    nrm3 = to_arm.to_3x3().inverted().transposed()
    gnames = [g.name for g in obj.vertex_groups]
    vweights = []
    for v in me.vertices:
        vweights.append({gnames[g.group]: g.weight for g in v.groups if g.weight > 0.001 and gnames[g.group] in arm.data.bones})
    head_z = None
    strands = []      # (points[], normals[], weights dict per point, uv)
    for tris in _islands(me):
        T = []
        for t in tris:
            uv = [mathutils.Vector(uvl[l].uv) for l in t.loops]
            vi = [me.loops[l].vertex_index for l in t.loops]
            T.append((uv, vi, t.normal.copy()))
        us = [p.x for uv, _, _ in T for p in uv]; vs = [p.y for uv, _, _ in T for p in uv]
        u0, u1, v0, v1 = min(us), max(us), min(vs), max(vs)
        if u1 - u0 < 1e-5 or v1 - v0 < 1e-5: continue

        def at(u, v):
            q = mathutils.Vector((u, v))
            for uv, vi, n in T:
                a, b, c = uv
                den = (b.y - c.y) * (a.x - c.x) + (c.x - b.x) * (a.y - c.y)
                if abs(den) < 1e-12: continue
                w0 = ((b.y - c.y) * (q.x - c.x) + (c.x - b.x) * (q.y - c.y)) / den
                w1 = ((c.y - a.y) * (q.x - c.x) + (a.x - c.x) * (q.y - c.y)) / den
                w2 = 1 - w0 - w1
                if min(w0, w1, w2) < -1e-4: continue
                p = sum((me.vertices[i].co * w for i, w in zip(vi, (w0, w1, w2))), mathutils.Vector())
                wd = {}
                for i, w in zip(vi, (w0, w1, w2)):
                    for k, x in vweights[i].items(): wd[k] = wd.get(k, 0.0) + x * w
                return to_arm @ p, (nrm3 @ n).normalized(), wd
            return None
        # which way do strands run? Cards are laid out with strands along V in the hair textures; take the longer
        # world direction as a check
        mid = at((u0 + u1) / 2, (v0 + v1) / 2)
        if mid is None: continue
        # root end: the root map is bright at roots; without one, the higher end
        rv = None
        if root_img is not None:
            ra = np.mean([_sample(root_img, u0 + (u1 - u0) * f, v0 + (v1 - v0) * 0.05)[0] for f in (0.25, 0.5, 0.75)])
            rb = np.mean([_sample(root_img, u0 + (u1 - u0) * f, v0 + (v1 - v0) * 0.95)[0] for f in (0.25, 0.5, 0.75)])
            if abs(ra - rb) > 0.08: rv = v0 if ra > rb else v1
        if rv is None:
            pa, pb = at((u0 + u1) / 2, v0 + (v1 - v0) * 0.02), at((u0 + u1) / 2, v1 - (v1 - v0) * 0.02)
            if pa is None or pb is None: continue
            rv = v0 if pa[0].z >= pb[0].z else v1
        tv = v1 if rv == v0 else v0
        left, right = at(u0 + (u1 - u0) * 0.02, (v0 + v1) / 2), at(u1 - (u1 - u0) * 0.02, (v0 + v1) / 2)
        width = (left[0] - right[0]).length if left and right else 0.01
        ra_, ta_ = at((u0 + u1) / 2, rv + (tv - rv) * 0.02), at((u0 + u1) / 2, tv + (rv - tv) * 0.02)
        length = (ra_[0] - ta_[0]).length if ra_ and ta_ else 0.05
        ns = max(1, min(48, int(width / spacing + 0.5)))
        npts = max(4, min(16, int(length / 0.025) + 2))
        for k in range(ns):
            u = u0 + (u1 - u0) * (k + 0.5) / ns
            pts, nrms, wts, cover = [], [], [], []
            for j in range(npts):
                v = rv + (tv - rv) * (0.02 + 0.96 * j / (npts - 1))
                s = at(u, v)
                if s is None: break
                a = _sample(alpha_img, u, v)
                cov = float(a[3]) if a is not None else 1.0
                if j >= 2 and cov < 0.12: break          # the strand thins out here
                pts.append(s[0]); nrms.append(s[1]); wts.append(s[2]); cover.append(cov)
            if len(pts) < 3 or (alpha_img is not None and np.mean(cover) < 0.25): continue
            strands.append((pts, nrms, wts, (u, rv)))
    if not strands:
        return None
    # ---- the curves object, laid out the way the Luna add-on's own strand import makes it
    cd = bpy.data.hair_curves.new(name)
    cd.add_curves([len(s[0]) for s in strands])
    cd.attributes['position'].data.foreach_set('vector', [c for s in strands for p in s[0] for c in p])
    na = cd.attributes.new('hair_normal', 'FLOAT_VECTOR', 'POINT')
    na.data.foreach_set('vector', [c for s in strands for n in s[1] for c in n])
    wattrs = [cd.attributes.new('hair_weight_%d' % k, 'FLOAT', 'POINT') for k in range(MAX_JOINTS)]
    jattrs = [cd.attributes.new('hair_joint_%d' % k, 'STRING', 'CURVE') for k in range(MAX_JOINTS)]
    uva = cd.attributes.new('hair_uv', 'FLOAT2', 'CURVE')
    bu = cd.attributes.new('hair_basis_u', 'FLOAT_VECTOR', 'CURVE'); bv = cd.attributes.new('hair_basis_v', 'FLOAT_VECTOR', 'CURVE')
    wflat = [[] for _ in range(MAX_JOINTS)]
    for si, (pts, nrms, wts, uv) in enumerate(strands):
        tot = {}
        for wd in wts:
            for k, x in wd.items(): tot[k] = tot.get(k, 0.0) + x
        names = [k for k, _ in sorted(tot.items(), key=lambda kv: -kv[1])[:MAX_JOINTS]]
        for k in range(MAX_JOINTS):
            jattrs[k].data[si].value = (names[k] if k < len(names) else '').encode('utf-8')
        for wd in wts:
            row = [wd.get(n, 0.0) for n in names]; ssum = sum(row) or 1.0
            for k in range(MAX_JOINTS): wflat[k].append(row[k] / ssum if k < len(row) else 0.0)
        uva.data[si].vector = uv
        d = (pts[-1] - pts[0]).normalized(); n = nrms[0]
        side = d.cross(n).normalized() if d.cross(n).length > 1e-6 else mathutils.Vector((1, 0, 0))
        bu.data[si].vector = side; bv.data[si].vector = n
    for k in range(MAX_JOINTS): wattrs[k].data.foreach_set('value', wflat[k])
    o = bpy.data.objects.new(name, cd)
    bpy.context.scene.collection.objects.link(o)
    o.parent = arm; o.matrix_parent_inverse = mathutils.Matrix.Identity(4); o.matrix_basis = mathutils.Matrix.Identity(4)
    o['engine_hair_subset_name'] = name
    o['engine_hair_skinning_type'] = 'joints'
    o['engine_hair_source'] = 'converted from Wolverine hair cards'
    raw = bytearray(donor_raw)
    c = [max(0.0, x) for x in colour[:3]]
    for i, f in enumerate((0.55, 0.75, 0.9, 1.05)):          # darker roots, lighter tips, like Spider-Man 2's own hair
        struct.pack_into('<3f', raw, 248 + 16 * i, *(min(1.0, x * f) for x in c))
    o['engine_hair_description_b64'] = base64.b64encode(bytes(raw)).decode('ascii')
    if H is not None:
        H._description_to_object_props(o, bytes(raw))
    log('  hair  %s: %d strands (%d points) from %d cards' % (name, len(strands), sum(len(s[0]) for s in strands), len(_islands(me))))
    return o
