#!/usr/bin/env python3
"""
model_to_blender.py - make a Marvel's Wolverine (PS5, i38) .model importable by the
"Luna Engine IO Tools" Blender add-on.

The add-on reads an older layout of the model format than the one this build uses:

                         add-on expects                 this build has
  geometry               inside the DAT1, in a block    outside the DAT1 (after it, and for
                         "Model Subset Geom Data"       split models partly in a second file)
  triangles              plain 16-bit index lists       meshlets (5-bit local indices plus a
                                                        per-meshlet vertex list)
  normals / tangents     two 10-bit azimuthal pairs     one tangent-frame quaternion (3 x 10 bits)
  mesh table rows        no meshlet count, UV scale     extra meshlet count at +16, UVs always
                         exponents at +22               in 1/16384 units
  "Model Look Built"     80-byte records, 7 sections    72-byte records, 6 sections

This script rewrites a model into the first form. Positions, UVs, skin weights,
shape data and materials are copied as they are; triangles are expanded to the same
triangles; normals and tangents are re-packed and match to within rounding.

Usage
  python model_to_blender.py hero.model.0 hero.model.1          (the two exported halves, any order)
  python model_to_blender.py hero.model                         (already combined, or never split)
  python model_to_blender.py --dir C:\\exports --recursive       (everything in a folder)
Output is written next to the input as <name>.blender.model unless -o / --out-dir is given.
The result is for importing only; it is not something the game can load.
"""
import argparse
import math
import os
import re
import struct
import sys

MODEL_TYPE = 0x648DBC7B
SEC_BUILT = 0x283D0383
SEC_SUBSETS = 0x78D9CBDE
SEC_LOOK_BUILT = 0x811902D7
SEC_GEOM = 0xF4EA9E18          # "Model Subset Geom Data"
SEC_MORPH = 0x948C38CD         # "Model Anim Morph2 Info"
SEC_MATERIAL = 0x3250BB80      # "Model Material"
ROW = 128
LABEL = b'Model Built Asset Data\0'


class ConvertError(Exception):
    pass


def align(n, a):
    return (n + a - 1) & ~(a - 1)


def unwrap(data):
    if data[:4] == b'1TAD':
        return data
    if data[:4] == b'STG\0' and len(data) >= 16:
        start = align(16 + struct.unpack_from('<I', data, 8)[0], 16)
        if data[start:start + 4] == b'1TAD':
            return data[start:]
        i = data.find(b'1TAD', 16, 1 << 20)
        if i >= 0:
            return data[i:]
    return None


def read_table(d):
    magic, typ, size, count, fixups = struct.unpack_from('<IIIHH', d, 0)
    if magic != 0x44415431:
        raise ConvertError('not a DAT1 file')
    entries = [list(struct.unpack_from('<3I', d, 16 + 12 * i)) for i in range(count)]
    return typ, size, count, fixups, entries


def decode_meshlets(geo, limit, base, row_index, idx_count, vtx_count, idx_off, meshlets):
    """Expand one subset's meshlets into a flat list of vertex indices (3 per triangle)."""
    start = base + idx_off
    if meshlets == 0:
        if idx_count:
            raise ConvertError('mesh %d has triangles but no meshlets' % row_index)
        return []
    if start + 24 * meshlets > limit:
        raise ConvertError('mesh %d: meshlet table runs past the geometry' % row_index)
    headers = struct.unpack_from('<%dI' % meshlets, geo, start)
    data = start + 24 * meshlets          # 4-byte header + 20-byte bounds per meshlet
    out = []
    for h in headers:
        unit = h & 0xFFFF
        nverts = ((h >> 17) & 0x7F) + 1
        ntris = (h >> 24) + 1
        p = data + unit * 16
        if p + 2 * (ntris + nverts) > limit:
            raise ConvertError('mesh %d: meshlet data runs past the geometry' % row_index)
        tris = struct.unpack_from('<%dH' % ntris, geo, p)
        verts = struct.unpack_from('<%dH' % nverts, geo, p + 2 * ntris)
        for t in tris:
            a, b, c = t & 31, (t >> 5) & 31, (t >> 10) & 31
            if a >= nverts or b >= nverts or c >= nverts:
                raise ConvertError('mesh %d: meshlet triangle uses a vertex it does not have' % row_index)
            out.append(verts[a]); out.append(verts[b]); out.append(verts[c])
    if len(out) != idx_count:
        raise ConvertError('mesh %d: decoded %d indices, expected %d' % (row_index, len(out), idx_count))
    if out and max(out) >= vtx_count:
        raise ConvertError('mesh %d: triangle refers to vertex %d of %d' % (row_index, max(out), vtx_count))
    return out


def reencode_frames(geo, base, vtx_count):
    """This build stores a tangent-frame quaternion per vertex (3 x 10 bits, stereographic);
    the add-on expects the normal and tangent as azimuthal-projected 10-bit pairs. Rewrite in place."""
    K = 0.35355339059327373          # sqrt(2) / 4
    for i in range(vtx_count):
        o = base + 16 * i
        word = struct.unpack_from('<I', geo, o + 8)[0]
        px = (word & 1023) / 511.5 - 1.0
        py = ((word >> 10) & 1023) / 511.5 - 1.0
        pz = ((word >> 20) & 1023) / 511.5 - 1.0
        s2 = px * px + py * py + pz * pz
        k = 2.0 / (1.0 + s2)
        x, y, z, w = px * k, py * k, pz * k, (1.0 - s2) / (1.0 + s2)
        nx, ny, nz = 2 * (x * z + w * y), 2 * (y * z - w * x), 1 - 2 * (x * x + y * y)     # frame Z = normal
        tx, ty, tz = 1 - 2 * (y * y + z * z), 2 * (x * y + w * z), 2 * (x * z - w * y)     # frame X = tangent
        s = math.sqrt((1.0 + abs(nz)) * 0.5)
        a = min(1023, max(0, int(math.floor((nx / s * K + 0.5) * 1023 + 0.5))))
        b = min(1023, max(0, int(math.floor((ny / s * K + 0.5) * 1023 + 0.5))))
        s = math.sqrt((1.0 + abs(tz)) * 0.5)
        c = min(1023, max(0, int(math.floor((tx / s * K + 0.5) * 1023 + 0.5))))
        d = min(1023, max(0, int(math.floor((ty / s * K + 0.5) * 1023 + 0.5))))
        out = a | (b << 10) | (c << 20) | ((1 << 30) if tz >= 0 else 0) | ((1 << 31) if nz >= 0 else 0)
        struct.pack_into('<hI', geo, o + 6, -d if word & (1 << 30) else d, out)


def convert_look_built(block, look_count):
    """72-byte records (6 section offsets) -> 80-byte records (7 section offsets)."""
    old_hdr = 72 * look_count
    if len(block) < old_hdr:
        raise ConvertError('Model Look Built is shorter than its records')
    grow = 8 * look_count
    recs = [struct.unpack_from('<6Q6H3I', block, 72 * i) for i in range(look_count)]
    starts = sorted(set([r[0] for r in recs] + [len(block)]))
    out = bytearray()
    for r in recs:
        offs = list(r[:6])
        if any(o < old_hdr or o > len(block) for o in offs):
            raise ConvertError('Model Look Built has an unexpected layout')
        look_end = min(s for s in starts if s > offs[0]) if offs[0] < len(block) else len(block)
        # the 7th section does not exist in this build: give it zero length at the end of this look's data
        out += struct.pack('<7Q6H3I', *([o + grow for o in offs] + [look_end + grow] + list(r[6:])))
    return bytes(out) + block[old_hdr:]


def material_names(d, secs):
    """Material asset paths, in the order the mesh rows index them."""
    if SEC_MATERIAL not in secs:
        return []
    off, size = secs[SEC_MATERIAL]
    count = size // 32
    names = []
    for i in range(count):
        p = struct.unpack_from('<I', d, off + 16 * i)[0]
        end = d.find(b'\0', p) if p < len(d) else -1
        names.append(d[p:end].decode('latin1') if end > p else '')
    return names


def hair_card_rows(f, names):
    """Some heads draw their hair at full detail with a strand system that is not in the model; the
    model then holds only an invisible "wrap mesh" shell at LOD0, and real hair cards from LOD3 down.
    Returns the rows of the most detailed hair cards, so they can be shown with the LOD0 meshes."""
    low = [n.lower() for n in names]
    if not any('wrapmesh' in n for n in low):
        return set()
    by_mat = {}
    for k, r in enumerate(f):
        by_mat.setdefault(r[8] & 0xFFFF, []).append(k)
    hair = [m for m in by_mat if m < len(low) and 'hair' in low[m] and 'wrapmesh' not in low[m]]
    if any(f[k][0] and (f[k][25] >> 16) & 1 for m in hair for k in by_mat[m]):
        return set()                                    # it has full-detail hair cards already
    rows = set()
    for m in hair:
        ks = by_mat[m]
        masks = [f[k][25] >> 16 for k in ks if f[k][0]]
        if not any(masks):
            continue
        best = min(x & -x for x in masks if x)          # lowest LOD that has these cards
        rows.update(k for k in ks if f[k][0] and (f[k][25] >> 16) & best)
    return rows


def convert(part0, part1=None):
    try:
        return _convert(part0, part1)
    except struct.error:
        raise ConvertError('the model file is damaged or truncated')


def _convert(part0, part1=None):
    """Returns (bytes, info). part0 = main file (maybe STG-wrapped, maybe already combined), part1 = streamed half or None."""
    p0 = unwrap(part0)
    if p0 is None:
        raise ConvertError('no DAT1 model found in the main file')
    typ, dsize, count, fixups, entries = read_table(p0)
    secs = {t: (o, s) for t, o, s in entries}
    notes = []
    if SEC_GEOM in secs:
        raise ConvertError('this model already has a "Model Subset Geom Data" block; it does not need converting')
    if typ != MODEL_TYPE:
        notes.append('unexpected DAT1 type %08x' % typ)
    if fixups:
        raise ConvertError('this model has a fixup table, which is not supported')
    for need, name in ((SEC_SUBSETS, 'Model Subset'), (SEC_LOOK_BUILT, 'Model Look Built')):
        if need not in secs:
            raise ConvertError('the model has no "%s" block' % name)
    table_end = 16 + 12 * count
    if p0[table_end:table_end + len(LABEL)] != LABEL:
        raise ConvertError('unexpected string table; cannot make room for a new block entry')

    sub_off, sub_size = secs[SEC_SUBSETS]
    nrows = sub_size // ROW
    rows = [bytes(p0[sub_off + ROW * k: sub_off + ROW * (k + 1)]) for k in range(nrows)]
    f = [struct.unpack('<32I', r) for r in rows]
    tail = p0[dsize:]

    # ---- gather the geometry into one buffer whose offsets are the rows' own base offsets
    rows_len = max((r[22] + r[23] for r in f), default=0)
    geo_len = rows_len

    # facial shape data (Morph2) lives in the geometry too, sometimes past the last mesh
    morph_need, hide_morph = 0, False
    if SEC_MORPH in secs:
        mo, ms = secs[SEC_MORPH]
        if ms < 112 or struct.unpack_from('<H', p0, mo + 6)[0]:      # truncated, or "stitched" (add-on cannot read it)
            hide_morph = True
        else:
            sizes = struct.unpack_from('<8I', p0, mo + 8)
            ptrs = struct.unpack_from('<8Q', p0, mo + 40)
            morph_need = max(ptrs[4] + sizes[2], ptrs[5] + sizes[4], ptrs[6] + sizes[7])
    if part1 is not None:
        p1 = part1
        expected = struct.unpack_from('<I', p0, secs[SEC_BUILT][0] + 88)[0] if SEC_BUILT in secs and secs[SEC_BUILT][1] >= 92 else None
        if expected and len(p1) != expected and p1[:4] == b'STG\0':
            start = align(16 + struct.unpack_from('<I', p1, 8)[0], 16)
            if len(p1) - start == expected:
                p1 = p1[start:]
        if expected is not None and len(p1) != expected:
            raise ConvertError('second half is %d bytes but the model expects %d - these two files do not belong together' % (len(p1), expected))
        streamed = [r for r in f if (r[25] >> 16) == 1]
        base = min((r[22] for r in streamed), default=None)
        end = max((r[22] + r[23] for r in streamed), default=None)
        if base is None or end - base != len(p1):
            base = rows_len - len(p1)
            if base < 0 or not any(r[22] == base for r in f):
                raise ConvertError('cannot find where the streamed geometry belongs')
        if base > len(tail):
            raise ConvertError('main file is truncated')
        geo = bytes(tail[:base]) + bytes(p1)
    else:
        expected = struct.unpack_from('<I', p0, secs[SEC_BUILT][0] + 88)[0] if SEC_BUILT in secs and secs[SEC_BUILT][1] >= 92 else 0
        if expected:
            # either an already-combined file or just the main half of a split model
            streamed = [r for r in f if (r[25] >> 16) == 1]
            base = min((r[22] for r in streamed), default=rows_len - expected)
            pad_end = align(base, 256)
            alone = (len(tail) < base + expected
                     or (tail[pad_end:pad_end + 8] == b'PSR_BVHP' and not any(tail[base:pad_end])))
            if alone:
                raise ConvertError('this is only the main half of a split model - give its second half too')
        geo = bytes(tail)
    if rows_len > len(geo):
        raise ConvertError('the geometry is incomplete (%d of %d bytes)' % (len(geo), rows_len))
    if morph_need > geo_len:
        if morph_need <= len(geo):
            geo_len = morph_need
        else:
            hide_morph = True
    geo = bytearray(geo[:geo_len])
    geo += b'\0' * (-len(geo) % 16)

    # ---- triangles: meshlets -> plain 16-bit lists appended to the geometry; rows -> the add-on's layout
    new_rows = bytearray()
    tri_total = 0
    done_frames = set()
    promote = hair_card_rows(f, material_names(p0, secs))
    for k, (row, r) in enumerate(zip(rows, f)):
        idx_count, vtx_count, idx_off, meshlets, base_off = r[0], r[1], r[3], r[4] & 0xFFFF, r[22]
        indices = decode_meshlets(geo, geo_len, base_off, k, idx_count, vtx_count, idx_off, meshlets) if idx_count else []
        if vtx_count and base_off not in done_frames:
            done_frames.add(base_off)
            if base_off + r[16] + 16 * vtx_count > geo_len:
                raise ConvertError('mesh %d: the vertices run past the geometry' % k)
            reencode_frames(geo, base_off + r[16], vtx_count)
        new_idx_off = len(geo) - base_off
        geo += struct.pack('<%dH' % len(indices), *indices)
        geo += b'\0' * (-len(geo) % 4)
        tri_total += len(indices) // 3
        n = bytearray(ROW)
        n[0:12] = row[0:12]
        struct.pack_into('<I', n, 12, new_idx_off if indices else 0)
        n[16:44] = row[20:48]            # 0xFFFF marker, flags, (flags2), units, material, areas, fade distance
        struct.pack_into('<H', n, 22, 0)  # UV scale exponents: this build always uses 1/16384
        # +44 (material LOD distance) does not exist in this build: left 0
        n[48:128] = row[48:128]          # centre, extents, stream offsets, base offset, LOD mask, ...
        if k in promote:                 # show these hair cards with the LOD0 meshes too
            struct.pack_into('<H', n, 102, (r[25] >> 16) | 1)
        new_rows += n

    # ---- Model Look Built
    lb_off, lb_size = secs[SEC_LOOK_BUILT]
    look_count = secs[0x06EB7EFC][1] // 64 if 0x06EB7EFC in secs else 0
    look_built = convert_look_built(bytes(p0[lb_off:lb_off + lb_size]), look_count)

    # ---- assemble: original DAT1 (rows patched in place) + new look-built + geometry
    out = bytearray(p0[:dsize])
    out[sub_off:sub_off + len(new_rows)] = new_rows
    out += b'\0' * (-len(out) % 16)
    new_lb_off = len(out)
    out += look_built
    out += b'\0' * (-len(out) % 16)
    geom_off = len(out)
    out += geo
    table = bytearray()
    for tag, off, size in entries:
        if tag == SEC_LOOK_BUILT:
            off, size = new_lb_off, len(look_built)
        if tag == SEC_MORPH and hide_morph:
            tag ^= 0x80000000          # unknown tag: the add-on then imports the model without shape keys
        table += struct.pack('<3I', tag, off, size)
    table += struct.pack('<3I', SEC_GEOM, geom_off, len(geo))
    # the new entry takes the first 12 bytes of the string table, which hold the unreferenced label
    out[16:16 + len(table)] = table
    struct.pack_into('<IH', out, 8, len(out), count + 1)
    if SEC_MORPH in secs and not hide_morph:
        # this build's mirror table has a different form; the add-on does not need it to import
        struct.pack_into('<H', out, secs[SEC_MORPH][0] + 4, 0)

    info = {'meshes': nrows, 'triangles': tri_total, 'looks': look_count, 'size': len(out),
            'geometry': len(geo), 'notes': notes, 'hair_cards': len(promote),
            'shapes': None if SEC_MORPH not in secs else ('left out' if hide_morph else 'kept')}
    return bytes(out), info


def describe(info):
    s = '%d meshes, %d triangles, %d looks, %d bytes' % (info['meshes'], info['triangles'], info['looks'], info['size'])
    if info.get('shapes'):
        s += ', facial shape data ' + info['shapes']
    for n in info['notes']:
        s += '\n      note: ' + n
    return s


# ------------------------------------------------------------------ command line

PAIR = [re.compile(r'^(?P<stem>.+\.model)[._ -]?(?P<n>[01])$', re.I),
        re.compile(r'^(?P<stem>.+?)[._ -](?P<n>[01])(?P<ext>\.model)$', re.I)]


def pair_key(name):
    for pat in PAIR:
        m = pat.match(name)
        if m:
            stem = m.group('stem')
            return (stem if stem.lower().endswith('.model') else stem + '.model'), int(m.group('n'))
    return None


def out_name(stem):
    return re.sub(r'\.model$', '', stem, flags=re.I) + '.blender.model'


def convert_paths(paths):
    blobs = [open(p, 'rb').read() for p in paths]
    mains = [b for b in blobs if unwrap(b) is not None]
    others = [b for b in blobs if unwrap(b) is None]
    if len(mains) != 1 or len(others) > 1:
        raise ConvertError('expected one model file, plus optionally its streamed half')
    return convert(mains[0], others[0] if others else None)


def main():
    ap = argparse.ArgumentParser(description='Convert a Wolverine i38 .model for the Luna Engine IO Blender add-on.')
    ap.add_argument('files', nargs='*')
    ap.add_argument('-o', '--out')
    ap.add_argument('--dir')
    ap.add_argument('--recursive', '-r', action='store_true')
    ap.add_argument('--out-dir')
    ap.add_argument('--overwrite', action='store_true')
    args = ap.parse_args()
    jobs = []
    if args.dir:
        walker = os.walk(args.dir) if args.recursive else [(args.dir, [], os.listdir(args.dir))]
        for root, _, files in walker:
            groups = {}
            for fn in files:
                if fn.lower().endswith('.blender.model'):
                    continue
                key = pair_key(fn)
                if key:
                    groups.setdefault(key[0], []).append(os.path.join(root, fn))
                elif fn.lower().endswith('.model'):
                    groups.setdefault(fn, []).append(os.path.join(root, fn))
            for stem, paths in sorted(groups.items()):
                halves = [p for p in paths if pair_key(os.path.basename(p))]
                use = halves if len(halves) == 2 else [p for p in paths if p not in halves] or paths
                rel = os.path.relpath(root, args.dir)
                jobs.append((use, os.path.normpath(os.path.join(args.out_dir or root, rel if args.out_dir else '', out_name(stem)))))
    elif args.files:
        key = pair_key(os.path.basename(args.files[0]))
        stem = key[0] if key else os.path.basename(args.files[0])
        jobs.append((args.files, args.out or os.path.join(args.out_dir or os.path.dirname(os.path.abspath(args.files[0])), out_name(stem))))
    else:
        print(__doc__)
        return 2
    failed = 0
    for paths, out in jobs:
        try:
            if os.path.exists(out) and not args.overwrite:
                raise ConvertError('%s already exists (use --overwrite)' % out)
            data, info = convert_paths(paths)
            os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
            with open(out, 'wb') as fh:
                fh.write(data)
            print('%s\n   %s' % (out, describe(info)))
        except ConvertError as e:
            failed += 1
            print('FAILED %s: %s' % (' + '.join(os.path.basename(p) for p in paths), e))
    if len(jobs) > 1:
        print('\n%d converted, %d failed' % (len(jobs) - failed, failed))
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
