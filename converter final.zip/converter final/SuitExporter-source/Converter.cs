// Turns a Marvel's Wolverine suit folder into Spider-Man 2 files before packing. The work is done by
// SM2Convert\wolverine_to_sm2.py, run inside Blender with the Luna Engine IO Tools add-on.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace SuitExport
{
    public class ConvertSettings
    {
        public string Blender = "", Luna = "", Peter = "", Miles = "", Sm2Textures = "", Sm2Material = "", WolverineGame = "", Heads = "auto", HairDonor = "", HairColour = "", Extracted = "";

        public static readonly string[] Keys = { "blender", "luna", "peter_template", "miles_template", "sm2_textures", "sm2_material", "wolverine_game", "heads", "hair_donor", "hair_colour", "wolverine_extracted" };
        public string Get(string k)
        {
            switch (k)
            {
                case "blender": return Blender; case "luna": return Luna; case "peter_template": return Peter; case "miles_template": return Miles;
                case "sm2_material": return Sm2Material; case "wolverine_game": return WolverineGame; case "heads": return Heads; case "hair_donor": return HairDonor; case "hair_colour": return HairColour; case "wolverine_extracted": return Extracted; default: return Sm2Textures;
            }
        }
        public void Set(string k, string v)
        {
            switch (k)
            {
                case "blender": Blender = v; break; case "luna": Luna = v; break; case "peter_template": Peter = v; break; case "miles_template": Miles = v; break;
                case "sm2_textures": Sm2Textures = v; break; case "sm2_material": Sm2Material = v; break; case "wolverine_game": WolverineGame = v; break;
                case "heads": Heads = (v == "keep" || v == "skip") ? v : "auto"; break;
                case "hair_donor": HairDonor = v; break; case "hair_colour": HairColour = v; break; case "wolverine_extracted": Extracted = v; break;
            }
        }

        /// <summary>A Spider-Man 2 material on the standard suit shader (hero_spiderman_suit_ggx), searched for under a folder.</summary>
        static string FindSuitMaterial(string folder)
        {
            if (!Directory.Exists(folder)) return null;
            var want = System.Text.Encoding.ASCII.GetBytes("hero_spiderman_suit_ggx.materialgraph");
            IEnumerable<string> files;
            try { files = Directory.GetFiles(folder, "*.material", SearchOption.AllDirectories); } catch (Exception) { return null; }
            foreach (var f in files.OrderBy(x => Path.GetFileName(x).ToLowerInvariant().Contains("_tor") ? 0 : 1).ThenBy(x => x, StringComparer.OrdinalIgnoreCase))
            {
                try
                {
                    var fi = new FileInfo(f); if (fi.Length > 65536) continue;
                    var b = File.ReadAllBytes(f);
                    if (b.Length > 3 && b[0] == (byte)'S' && b[1] == (byte)'T' && b[2] == (byte)'G' && IndexOf(b, want) >= 0) return f;
                }
                catch (Exception) { }
            }
            return null;
        }
        static int IndexOf(byte[] h, byte[] n)
        {
            for (int i = 0; i + n.Length <= h.Length; i++) { int k = 0; while (k < n.Length && h[i + k] == n[k]) k++; if (k == n.Length) return i; }
            return -1;
        }

        /// <summary>Fills empty fields with the usual places.</summary>
        public void Guess(string exeDir)
        {
            string home = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            var roots = new List<string> { exeDir, Path.Combine(home, "Downloads"), Path.Combine(home, "Desktop"), Path.Combine(home, "Documents") };
            try { roots.Add(Path.GetDirectoryName(exeDir)); } catch (Exception) { }
            if (!File.Exists(Blender))
            {
                var cands = new List<string>();
                foreach (var pf in new[] { Environment.GetEnvironmentVariable("ProgramFiles"), Environment.GetEnvironmentVariable("ProgramFiles(x86)"), @"C:\Program Files" })
                {
                    if (string.IsNullOrEmpty(pf)) continue;
                    string bf = Path.Combine(pf, "Blender Foundation");
                    try { if (Directory.Exists(bf)) cands.AddRange(Directory.GetDirectories(bf).Select(d => Path.Combine(d, "blender.exe"))); } catch (Exception) { }
                    cands.Add(Path.Combine(pf, @"Steam\steamapps\common\Blender\blender.exe"));
                }
                cands.Add(@"C:\Program Files (x86)\Steam\steamapps\common\Blender\blender.exe");
                Blender = cands.Where(File.Exists).OrderByDescending(x => x, StringComparer.OrdinalIgnoreCase).FirstOrDefault() ?? Blender;
            }
            if (!Directory.Exists(Luna)) Luna = roots.Select(r => Path.Combine(r, "luna_engine_io_tools")).FirstOrDefault(d => File.Exists(Path.Combine(d, "model_export.py"))) ?? Luna;
            if (!File.Exists(Peter)) Peter = roots.SelectMany(r => new[] { Path.Combine(r, @"adv\peter\hero_spiderman_advanced.model"), Path.Combine(r, @"peter\hero_spiderman_advanced.model") }).FirstOrDefault(File.Exists) ?? Peter;
            if (!File.Exists(Miles)) Miles = roots.SelectMany(r => new[] { Path.Combine(r, @"adv\miles\hero_spiderman_miles_updated.model"), Path.Combine(r, @"miles\hero_spiderman_miles_updated.model") }).FirstOrDefault(File.Exists) ?? Miles;
            if (string.IsNullOrEmpty(Sm2Textures) || !Sm2Textures.Split(';').Any(Directory.Exists))
            {
                var t = new List<string>();
                var s2 = roots.Select(r => Path.Combine(r, "sm2suits")).FirstOrDefault(Directory.Exists); if (s2 != null) t.Add(s2);
                if (File.Exists(Peter)) { try { t.Add(Path.GetDirectoryName(Path.GetDirectoryName(Peter))); } catch (Exception) { } }
                if (t.Count > 0) Sm2Textures = string.Join(";", t.Distinct(StringComparer.OrdinalIgnoreCase).ToArray());
            }
            if (!File.Exists(Sm2Material))
                Sm2Material = roots.Select(r => Path.Combine(r, "sm2suits")).Concat(roots.Select(r => Path.Combine(r, "adv"))).Select(FindSuitMaterial).FirstOrDefault(x => x != null) ?? Sm2Material;
            if (!Directory.Exists(Extracted))
                Extracted = roots.SelectMany(r => new[] { Path.Combine(r, @"dat1\extracted"), Path.Combine(r, "extracted") })
                                 .FirstOrDefault(d => Directory.Exists(Path.Combine(d, "characters"))) ?? Extracted;
            if (!File.Exists(HairDonor))
            {
                foreach (var r in roots)
                {
                    foreach (var d in new[] { Path.Combine(r, "kraven model"), Path.Combine(r, "kraven"), Path.Combine(r, "sm2suits") })
                    {
                        try { if (Directory.Exists(d)) { var f = Directory.GetFiles(d, "*.model", SearchOption.AllDirectories).FirstOrDefault(x => Path.GetFileName(x).ToLowerInvariant().Contains("kraven")); if (f != null) { HairDonor = f; break; } } } catch (Exception) { }
                    }
                    if (File.Exists(HairDonor)) break;
                }
            }
            if (!File.Exists(Path.Combine(WolverineGame ?? "", "toc")))
            {
                var g = new List<string> { @"C:\wolverine\i38\Wolverine\Wolverine\PPSA03671-app0" };
                g.AddRange(roots.Select(r => Path.Combine(r, "PPSA03671-app0")));
                foreach (var ini in roots.SelectMany(r => new[] { Path.Combine(r, @"WolverineTweaks\WolverineTweaks.ini"), Path.Combine(r, @"dat1\WolverineTweaks\WolverineTweaks.ini") }))
                {
                    try { if (File.Exists(ini)) foreach (var l in File.ReadAllLines(ini)) if (l.StartsWith("game=")) g.Insert(0, l.Substring(5).Trim()); } catch (Exception) { }
                }
                WolverineGame = g.FirstOrDefault(d => File.Exists(Path.Combine(d, "toc")) && File.Exists(Path.Combine(d, "eboot.bin"))) ?? WolverineGame;
            }
        }

        /// <summary>What is missing for converting for the given heroes (empty = ready).</summary>
        public string Missing(bool peter, bool miles, string exeDir)
        {
            var m = new List<string>();
            if (!File.Exists(Path.Combine(Converter.ToolsDir(exeDir), "wolverine_to_sm2.py"))) m.Add("the SM2Convert folder next to SuitExporter.exe");
            if (!File.Exists(Blender)) m.Add("Blender 5 (blender.exe)");
            if (!File.Exists(Path.Combine(Luna ?? "", "model_export.py"))) m.Add("the luna_engine_io_tools add-on folder");
            if (peter && !File.Exists(Peter)) m.Add("Peter's template model (hero_spiderman_advanced.model from Spider-Man 2)");
            if (miles && !File.Exists(Miles)) m.Add("Miles's template model (a Miles .model from Spider-Man 2)");
            return string.Join(", ", m);
        }
    }

    public static class Converter
    {
        public static string ToolsDir(string exeDir) { return Path.Combine(exeDir, "SM2Convert"); }

        /// <summary>Runs the conversion. Returns the folder made for each hero (true = Peter).</summary>
        public static Dictionary<bool, string> Run(SuitProject p, ExportOptions o, string work, Action<string> line)
        {
            var cs = o.Convert;
            Directory.CreateDirectory(work);
            string script = Path.Combine(ToolsDir(o.ExeDir), "wolverine_to_sm2.py");
            var args = new StringBuilder();
            Action<string, string> add = (k, v) => { if (!string.IsNullOrEmpty(v)) args.Append(' ').Append(k).Append(' ').Append(Q(v)); };
            args.Append("-b --factory-startup --python ").Append(Q(script)).Append(" --");
            add("--suit", p.Folder); add("--out", work); add("--luna", cs.Luna); add("--id", p.Id);
            if (o.Peter) add("--peter", cs.Peter);
            if (o.Miles) add("--miles", cs.Miles);
            var texDirs = (cs.Sm2Textures ?? "").Split(';').Where(Directory.Exists).ToArray();
            if (texDirs.Length > 0) add("--sm2-textures", string.Join(";", texDirs));
            if (File.Exists(cs.Sm2Material)) add("--sm2-material", cs.Sm2Material);
            if (File.Exists(Path.Combine(cs.WolverineGame ?? "", "toc"))) add("--wolverine-game", cs.WolverineGame);
            if (cs.Heads == "keep" || cs.Heads == "skip") add("--heads", cs.Heads);
            foreach (var ex in (cs.Extracted ?? "").Split(';').Where(Directory.Exists)) add("--extracted", ex);
            if (File.Exists(cs.HairDonor)) add("--hair-donor", cs.HairDonor);
            if (!string.IsNullOrEmpty(cs.HairColour)) add("--hair-colour", cs.HairColour.Trim());
            var psi = new ProcessStartInfo(cs.Blender, args.ToString())
            {
                UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true,
                WorkingDirectory = ToolsDir(o.ExeDir), StandardOutputEncoding = Encoding.UTF8
            };
            var all = new StringBuilder();
            using (var proc = new Process { StartInfo = psi })
            {
                proc.OutputDataReceived += (s, e) => { if (e.Data == null) return; lock (all) all.AppendLine(e.Data); if (e.Data.StartsWith("[sm2] ") && line != null) line(e.Data.Substring(6)); };
                proc.ErrorDataReceived += (s, e) => { if (e.Data != null) lock (all) all.AppendLine(e.Data); };
                proc.Start(); proc.BeginOutputReadLine(); proc.BeginErrorReadLine();
                proc.WaitForExit();
                try { File.WriteAllText(Path.Combine(work, "blender_output.txt"), all.ToString()); } catch (Exception) { }
            }
            var res = new Dictionary<bool, string>();
            foreach (bool peter in new[] { true, false })
            {
                if (peter ? !o.Peter : !o.Miles) continue;
                string d = Path.Combine(work, p.Id + (peter ? "_peter" : "_miles"));
                if (Directory.Exists(Path.Combine(d, "0"))) res[peter] = d;
            }
            if (res.Count == 0)
            {
                string log = Path.Combine(work, p.Id + "_convert_log.txt");
                throw new InvalidOperationException("The conversion made no files. See " + (File.Exists(log) ? log : Path.Combine(work, "blender_output.txt")));
            }
            return res;
        }

        static string Q(string s) { return "\"" + s.TrimEnd('\\') + "\""; }
    }
}
