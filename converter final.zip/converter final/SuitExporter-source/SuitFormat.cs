// Marvel's Spider-Man 2 (PC) ".suit" writer.
//
// This is a port of the relevant parts of Overstrike and its Suit Tool by Tkachov (GPL, github.com/Tkachov/Overstrike):
// the .suit container, the DSAR/LZ4 block archive inside it, and the four configs a suit needs. The port is checked
// against that code itself: configs come out byte for byte identical, and Overstrike's own reader loads the files.
// This program is free software under the GNU General Public License, like the code it is ported from.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace SuitExport
{
    public static class Hashes
    {
        static readonly uint[] T32 = MakeT32();
        static readonly ulong[] T64 = MakeT64();
        static uint[] MakeT32()
        {
            var t = new uint[256];
            for (uint i = 0; i < 256; i++) { uint c = i; for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? (c >> 1) ^ 0xEDB88320u : c >> 1; t[i] = c; }
            return t;
        }
        static ulong[] MakeT64()
        {
            var t = new ulong[256];
            for (ulong i = 0; i < 256; i++) { ulong c = i; for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? (c >> 1) ^ 0xC96C5795D7870F42UL : c >> 1; t[i] = c; }
            return t;
        }
        /// <summary>Lower case, forward slashes, no doubled or leading/trailing slashes.</summary>
        public static string Normalize(string s)
        {
            string r = s.ToLowerInvariant().Replace('\\', '/');
            var sb = new StringBuilder(); bool slash = false;
            foreach (char c in r) { if (c == '/') { if (slash) continue; slash = true; } else slash = false; sb.Append(c); }
            string o = sb.ToString();
            if (o.StartsWith("/")) o = o.Substring(1);
            if (o.EndsWith("/")) o = o.Substring(0, o.Length - 1);
            return o;
        }
        public static uint Crc32(string s, bool normalize)
        {
            if (normalize) s = Normalize(s);
            uint c = 0xEDB88320u;
            foreach (byte b in Encoding.UTF8.GetBytes(s)) c = T32[(c ^ b) & 0xFF] ^ (c >> 8);
            return c;
        }
        /// <summary>The id the game knows an asset by: CRC-64 of its normalised path.</summary>
        public static ulong AssetId(string path)
        {
            ulong c = 0xC96C5795D7870F42UL;
            foreach (byte b in Encoding.UTF8.GetBytes(Normalize(path))) c = T64[(c ^ b) & 0xFF] ^ (c >> 8);
            return (c >> 2) | 0x8000000000000000UL;
        }
    }

    // ------------------------------------------------------------------------------------------ config values
    public class JObj
    {
        public readonly List<KeyValuePair<string, object>> Props = new List<KeyValuePair<string, object>>();   // string, bool, JObj, or List<object>
        public JObj Add(string name, object value) { Props.Add(new KeyValuePair<string, object>(name, value)); return this; }
    }

    /// <summary>Builds a config asset the way Overstrike's Config class does, wrapped in its STG file form.</summary>
    public class ConfigAsset
    {
        const uint CONFIG_TYPE = 0x35F7AFA5, SEC_TYPE = 0x4A128222, SEC_BUILT = 0xE501186F, SEC_REFS = 0x58B8558A;
        public string Type; public JObj Data = new JObj(); public List<string> References;   // null = no reference section

        MemoryStream strings; int stringsStart; long global;

        uint AddString(string s)
        {
            uint off = (uint)(stringsStart + strings.Length);
            var b = Encoding.UTF8.GetBytes(s); strings.Write(b, 0, b.Length); strings.WriteByte(0);
            return off;
        }
        static byte TypeOf(object v)
        {
            if (v == null) return 0x13;
            if (v is bool) return 0x0F;
            if (v is string) return 0x0A;
            if (v is JObj) return 0x0D;
            var l = v as List<object>;
            if (l != null) return l.Count == 0 ? (byte)0x13 : TypeOf(l[0]);
            throw new InvalidOperationException("Unsupported config value");
        }
        void PadGlobal(BinaryWriter w, int a) { long r = global % a; if (r > 0) { for (long i = 0; i < a - r; i++) w.Write((byte)0); global += a - r; } }
        void WriteNode(BinaryWriter w, object v, byte type)
        {
            switch (type)
            {
                case 0x0A:
                    {
                        string s = (string)v; var b = Encoding.UTF8.GetBytes(s); int extra = 1; int rem = (b.Length + extra) % 4; if (rem != 0) extra += 4 - rem;
                        w.Write((uint)b.Length); w.Write(s == "" ? 0u : Hashes.Crc32(s, false)); w.Write(s == "" ? 0UL : Hashes.AssetId(s));
                        w.Write(b); for (int i = 0; i < extra; i++) w.Write((byte)0);
                        global += 16 + b.Length + extra; break;
                    }
                case 0x0D: WriteObject(w, (JObj)v); break;
                case 0x0F: w.Write((bool)v); global += 1; break;
                default: w.Write((byte)0); global += 1; break;
            }
        }
        void WriteObject(BinaryWriter w, JObj obj)
        {
            global += 16;
            var ms = new MemoryStream(); var w2 = new BinaryWriter(ms);
            var offs = new List<uint>(); var types = new List<byte>();
            foreach (var p in obj.Props)
            {
                offs.Add(AddString(p.Key)); byte t = TypeOf(p.Value); types.Add(t);
                ushort flags = 1 << 4; var arr = p.Value as List<object>;
                if (arr != null) flags = (ushort)(((uint)arr.Count << 4) | 1);
                w2.Write(Hashes.Crc32(p.Key, false)); w2.Write(flags); w2.Write((byte)0); w2.Write(t);
            }
            foreach (uint o in offs) w2.Write(o);
            int n = obj.Props.Count;
            global += n * 12;
            if (n > 0) PadGlobal(w2, 4);
            for (int i = 0; i < n; i++)
            {
                var arr = obj.Props[i].Value as List<object>;
                if (arr != null) { if (arr.Count == 0) { w2.Write((byte)0); global++; } else foreach (var e in arr) WriteNode(w2, e, types[i]); }
                else WriteNode(w2, obj.Props[i].Value, types[i]);
            }
            uint emptySize = 0;
            if (n > 0) PadGlobal(w2, 4); else { long before = global; PadGlobal(w2, 4); emptySize = (uint)(global - before); }
            var data = ms.ToArray();
            w.Write(0u); w.Write(0x03150044u); w.Write((uint)n); w.Write(n > 0 ? (uint)data.Length : emptySize); w.Write(data);
        }
        byte[] Section(JObj o) { global = 0; var ms = new MemoryStream(); WriteObject(new BinaryWriter(ms), o); return ms.ToArray(); }

        /// <summary>The DAT1 container alone.</summary>
        public byte[] Dat1()
        {
            int count = References != null ? 3 : 2;
            strings = new MemoryStream(); stringsStart = 16 + 12 * count;
            AddString("Config Built File");
            byte[] type = Section(new JObj().Add("Type", Type));
            byte[] built = Section(Data);
            byte[] refs = null;
            if (References != null)
            {
                var ms = new MemoryStream(); var w = new BinaryWriter(ms);
                foreach (var r0 in References)
                {
                    string r = r0.Replace('/', '\\');
                    int dot = r.LastIndexOf('.');
                    if (dot < 0) throw new InvalidOperationException("Reference without an extension: " + r);
                    ulong id = Hashes.AssetId(r); uint off = AddString(r); uint ext = Hashes.Crc32(r.Substring(dot), true);
                    w.Write(id); w.Write(off); w.Write(ext);
                }
                refs = ms.ToArray();
            }
            // sections are laid out in the order they were added (type, built, references); the table is sorted by tag
            var order = new List<KeyValuePair<uint, byte[]>> { new KeyValuePair<uint, byte[]>(SEC_TYPE, type), new KeyValuePair<uint, byte[]>(SEC_BUILT, built) };
            if (refs != null) order.Add(new KeyValuePair<uint, byte[]>(SEC_REFS, refs));
            long offset = 16 + 12 * count + strings.Length;
            var where = new Dictionary<uint, uint>();
            foreach (var s in order) { if (offset % 16 != 0) offset += 16 - offset % 16; where[s.Key] = (uint)offset; offset += s.Value.Length; }
            var outp = new MemoryStream(); var bw = new BinaryWriter(outp);
            bw.Write(0x44415431u); bw.Write(CONFIG_TYPE); bw.Write((uint)offset); bw.Write((ushort)count); bw.Write((ushort)0);
            foreach (var s in order.OrderBy(x => x.Key)) { bw.Write(s.Key); bw.Write(where[s.Key]); bw.Write((uint)s.Value.Length); }
            bw.Write(strings.ToArray());
            foreach (var s in order) { while (outp.Position < where[s.Key]) bw.Write((byte)0); bw.Write(s.Value); }
            return outp.ToArray();
        }
        /// <summary>The 16-byte asset header the game's table of contents keeps for a config: type id and size.</summary>
        public static byte[] Header(int dat1Length)
        {
            var ms = new MemoryStream(); var w = new BinaryWriter(ms);
            w.Write(CONFIG_TYPE); w.Write((byte)0); w.Write((byte)1); w.Write((ushort)0); w.Write((uint)dat1Length); w.Write(0u);
            return ms.ToArray();
        }
    }

    // ------------------------------------------------------------------------------------------ STG files
    /// <summary>An asset as the mod tools keep it on disk: optional table-of-contents header and texture info, then the data.</summary>
    public class StgFile
    {
        public byte[] Header, TextureMeta, Raw;
        public static StgFile FromRaw(byte[] raw, byte[] header = null) { return new StgFile { Raw = raw, Header = header }; }
        public static StgFile Load(string path) { return Parse(File.ReadAllBytes(path)); }
        public static StgFile Parse(byte[] b)
        {
            if (b.Length >= 16 && (BitConverter.ToUInt32(b, 0) & 0xFFFFFF) == 0x475453)
            {
                if ((b[3]) != 0) throw new InvalidDataException("Unknown STG version");
                int hs = BitConverter.ToInt32(b, 8), ts = BitConverter.ToInt32(b, 12);
                int p = 16; var s = new StgFile();
                s.Header = Sub(b, p, hs); p += hs; p = (p + 15) & ~15;
                s.TextureMeta = Sub(b, p, ts); p += ts; p = (p + 15) & ~15;
                s.Raw = Sub(b, p, b.Length - p);
                // Overstrike keeps zero-length arrays here, and writes their length (0) into the suit
                return s;
            }
            return new StgFile { Raw = b };
        }
        static byte[] Sub(byte[] b, int off, int len) { var r = new byte[len]; Buffer.BlockCopy(b, off, r, 0, len); return r; }
        public byte[] Save()
        {
            var ms = new MemoryStream(); var w = new BinaryWriter(ms);
            if (Header != null || TextureMeta != null)
            {
                uint flags = 0; if (Header != null) flags |= 1; if (TextureMeta != null && TextureMeta.Length > 0) flags |= 2;
                w.Write(0x00475453u); w.Write(flags); w.Write((uint)(Header == null ? 0 : Header.Length)); w.Write((uint)(TextureMeta == null ? 0 : TextureMeta.Length));
                if (Header != null) { w.Write(Header); while (ms.Position % 16 != 0) w.Write((byte)0); }
                if (TextureMeta != null) { w.Write(TextureMeta); while (ms.Position % 16 != 0) w.Write((byte)0); }
            }
            w.Write(Raw);
            return ms.ToArray();
        }
        /// <summary>DAT1 type id of the data, or 0 when the data is not a DAT1 container.</summary>
        public uint Dat1Type { get { return Raw != null && Raw.Length >= 16 && BitConverter.ToUInt32(Raw, 0) == 0x44415431 ? BitConverter.ToUInt32(Raw, 4) : 0; } }
    }

    // ------------------------------------------------------------------------------------------ LZ4 + DSAR
    public static class Lz4
    {
        /// <summary>LZ4 block compression (greedy, 64 KB window). Output is a standard LZ4 block.</summary>
        public static int Encode(byte[] src, int srcOff, int srcLen, byte[] dst)
        {
            const int MINMATCH = 4, MFLIMIT = 12, LASTLITERALS = 5, HASH_BITS = 16;
            int d = 0, anchor = srcOff, ip = srcOff, end = srcOff + srcLen;
            if (srcLen >= MFLIMIT + 1)
            {
                var table = new int[1 << HASH_BITS];
                for (int i = 0; i < table.Length; i++) table[i] = -1;
                int mflimit = end - MFLIMIT, matchLimit = end - LASTLITERALS;
                while (ip < mflimit)
                {
                    uint seq = BitConverter.ToUInt32(src, ip);
                    int h = (int)((seq * 2654435761u) >> (32 - HASH_BITS));
                    int cand = table[h]; table[h] = ip;
                    if (cand < 0 || ip - cand > 65535 || BitConverter.ToUInt32(src, cand) != seq) { ip++; continue; }
                    int m = MINMATCH;
                    while (ip + m < matchLimit && src[cand + m] == src[ip + m]) m++;
                    int lit = ip - anchor;
                    int token = d++;
                    if (lit >= 15) { dst[token] = 0xF0; int l = lit - 15; while (l >= 255) { dst[d++] = 255; l -= 255; } dst[d++] = (byte)l; }
                    else dst[token] = (byte)(lit << 4);
                    Buffer.BlockCopy(src, anchor, dst, d, lit); d += lit;
                    int off = ip - cand; dst[d++] = (byte)off; dst[d++] = (byte)(off >> 8);
                    int ml = m - MINMATCH;
                    if (ml >= 15) { dst[token] |= 15; ml -= 15; while (ml >= 255) { dst[d++] = 255; ml -= 255; } dst[d++] = (byte)ml; }
                    else dst[token] |= (byte)ml;
                    ip += m; anchor = ip;
                }
            }
            {
                int lit = end - anchor; int token = d++;
                if (lit >= 15) { dst[token] = 0xF0; int l = lit - 15; while (l >= 255) { dst[d++] = 255; l -= 255; } dst[d++] = (byte)l; }
                else dst[token] = (byte)(lit << 4);
                Buffer.BlockCopy(src, anchor, dst, d, lit); d += lit;
            }
            return d;
        }
        public static void Decode(byte[] src, int srcOff, int srcLen, byte[] dst, int dstOff, int dstLen)
        {
            int s = srcOff, sEnd = srcOff + srcLen, d = dstOff, dEnd = dstOff + dstLen;
            while (s < sEnd)
            {
                int token = src[s++]; int lit = token >> 4;
                if (lit == 15) { int b; do { b = src[s++]; lit += b; } while (b == 255); }
                Buffer.BlockCopy(src, s, dst, d, lit); s += lit; d += lit;
                if (s >= sEnd) break;
                int off = src[s] | (src[s + 1] << 8); s += 2;
                int ml = token & 15;
                if (ml == 15) { int b; do { b = src[s++]; ml += b; } while (b == 255); }
                ml += 4;
                int from = d - off; if (from < dstOff) throw new InvalidDataException("bad LZ4 offset");
                for (int i = 0; i < ml; i++) dst[d++] = dst[from++];
            }
            if (d != dEnd) throw new InvalidDataException("LZ4 block decoded to the wrong size");
        }
    }

    /// <summary>The block-compressed archive form the PC games read ("DSAR"), written straight to a stream.</summary>
    public class DsarWriter
    {
        const int BLOCK = 262144;
        public readonly long OriginalSize;
        readonly Stream outp; readonly long start; readonly int blocks; int index; long realOffset;
        readonly byte[] buf = new byte[BLOCK]; int fill; readonly byte[] comp = new byte[BLOCK * 2];
        public byte[] First16 { get; private set; }

        public DsarWriter(Stream output, long originalSize)
        {
            outp = output; OriginalSize = originalSize; start = output.Position;
            blocks = (int)(originalSize / BLOCK) + (originalSize % BLOCK != 0 ? 1 : 0);
            var w = new BinaryWriter(output);
            w.Write(0x52415344u); w.Write(0x10003u); w.Write((uint)blocks); w.Write((uint)(32 + blocks * 32)); w.Write((ulong)originalSize); w.Write(Encoding.ASCII.GetBytes("PADDING*"));
            for (int i = 0; i < blocks; i++) { w.Write(0UL); w.Write(0UL); w.Write(0u); w.Write(0u); w.Write((byte)3); for (int j = 0; j < 7; j++) w.Write((byte)0x55); }
            var ms = new MemoryStream(); var hw = new BinaryWriter(ms);
            hw.Write(0x52415344u); hw.Write(0x10003u); hw.Write((uint)blocks); hw.Write((uint)(32 + blocks * 32));
            First16 = ms.ToArray();
        }
        public void Write(byte[] data, int off, int len)
        {
            while (len > 0)
            {
                int n = Math.Min(len, BLOCK - fill);
                Buffer.BlockCopy(data, off, buf, fill, n); fill += n; off += n; len -= n;
                if (fill == BLOCK) Flush();
            }
        }
        void Flush()
        {
            if (fill == 0) return;
            long compOffset = outp.Position - start;
            int c = Lz4.Encode(buf, 0, fill, comp);
            outp.Write(comp, 0, c);
            long back = outp.Position;
            outp.Position = start + 32 + index * 32;
            var w = new BinaryWriter(outp);
            w.Write((ulong)realOffset); w.Write((ulong)compOffset); w.Write((uint)fill); w.Write((uint)c);
            outp.Position = back;
            realOffset += fill; fill = 0; index++;
        }
        public void Finish()
        {
            Flush();
            if (realOffset != OriginalSize || index != blocks) throw new InvalidOperationException("Archive size mismatch");
        }
    }

    // ------------------------------------------------------------------------------------------ the suit itself
    /// <summary>One asset going into a suit: either bytes in memory or a region of a file on disk.</summary>
    public class SuitAsset
    {
        public byte Span; public string Path; public ulong Id;
        public byte[] Header, Meta;          // what the game's table of contents will store next to the asset (may be null)
        public byte[] Data;                  // in memory, or:
        public string File; public long RawOffset, RawLength;
        public long Length { get { return Data != null ? Data.Length : RawLength; } }

        /// <summary>An asset from a file as the mod tools write it (STG wrapper or bare data), without reading the body.</summary>
        public static SuitAsset FromFile(string file, byte span, string assetPath)
        {
            var a = new SuitAsset { Span = span, Path = assetPath, Id = Hashes.AssetId(assetPath), File = file };
            using (var f = System.IO.File.OpenRead(file))
            {
                var head = new byte[16]; int n = f.Read(head, 0, 16);
                if (n == 16 && (BitConverter.ToUInt32(head, 0) & 0xFFFFFF) == 0x475453)
                {
                    if (head[3] != 0) throw new InvalidDataException("Unknown STG version in " + file);
                    int hs = BitConverter.ToInt32(head, 8), ts = BitConverter.ToInt32(head, 12);
                    if (hs < 0 || ts < 0 || 16L + hs + ts > f.Length) throw new InvalidDataException("Damaged STG header in " + file);
                    a.Header = new byte[hs]; f.Read(a.Header, 0, hs); f.Position = (f.Position + 15) & ~15L;
                    a.Meta = new byte[ts]; f.Read(a.Meta, 0, ts); f.Position = (f.Position + 15) & ~15L;
                    a.RawOffset = Math.Min(f.Position, f.Length); a.RawLength = f.Length - a.RawOffset;
                }
                else { a.RawOffset = 0; a.RawLength = f.Length; }
            }
            return a;
        }
        /// <summary>First bytes of the data (for type checks).</summary>
        public byte[] Peek(int count)
        {
            if (Data != null) return Data.Take(count).ToArray();
            using (var f = System.IO.File.OpenRead(File)) { f.Position = RawOffset; var b = new byte[(int)Math.Min(count, RawLength)]; f.Read(b, 0, b.Length); return b; }
        }
    }

    public class SuitSpec
    {
        public string Id, ModName, Author, SuitName, Icon, MainModel, MaskModel; public bool Peter = true, BlackWebs, TentacleTraversal;
        public List<SuitAsset> Assets = new List<SuitAsset>();
    }

    public static class SuitWriter
    {
        static List<object> L(params object[] items) { return new List<object>(items); }

        /// <summary>The four configs Suit Tool generates for a suit, with their asset paths.</summary>
        public static List<KeyValuePair<string, ConfigAsset>> Configs(SuitSpec s)
        {
            string id = s.Id, dir = "suits/" + id + "/configs/";
            string rewardPath = dir + "inv_reward_loadout_" + id + ".config", varGroupPath = dir + "inv_" + id + "_variant_group.config";
            string loadoutPath = dir + "itemloadout_" + id + ".config", varGroupLoadoutPath = dir + "itemloadout_" + id + "_variant_group.config";
            string vanityPath = dir + "vanity_" + id + ".config";

            var mask = new JObj(); if (!string.IsNullOrEmpty(s.MaskModel)) mask.Add("AssetPath", s.MaskModel); mask.Add("Autoload", false);
            var reward = new ConfigAsset { Type = "VanityLoadoutItemConfig" };
            reward.Data.Add("DamagedLoadoutConfig", new JObj().Add("Autoload", false))
                .Add("DamagedMasklessLoadoutConfig", new JObj().Add("Autoload", false))
                .Add("DefaultLoadoutConfig", new JObj().Add("AssetPath", loadoutPath).Add("Autoload", false))
                .Add("DefaultMaskModel", mask)
                .Add("MasklessLoadoutConfig", new JObj().Add("Autoload", false))
                .Add("Name", id).Add("PhotoModeSuitHealthEnabled", true).Add("Stackable", false)
                .Add("ValidCharacters", L(s.Peter ? "kSpiderManPeter" : "kSpiderManMiles"));

            string[] items = s.Peter
                ? new[] { "configs/VanityBodyType/VanityBody_SpiderMan.config", "configs/VanityHED/VanityHEDSpiderMan1.config", vanityPath }
                : new[] { "configs/VanityBodyType/VanityBody_MilesMorales.config", vanityPath, "configs/vanitytor1/vanity_i30_miles_venomxray.config" };
            var loadout = new ConfigAsset { Type = "ItemLoadoutConfig", References = items.ToList() };
            loadout.Data.Add("Loadout", new JObj()
                .Add("ItemLoadoutLists", L(new JObj().Add("Items", L(items.Select(i => (object)new JObj().Add("Item", i)).ToArray()))))
                .Add("Name", id));

            string conduit = s.Peter ? "conduit/characters/hero/hero_aud_vanity_spim_default/hero_aud_vanity_spip_default.conduit"
                                     : "conduit/characters/hero/hero_aud_vanity_spim_default/hero_aud_vanity_spim_default.conduit";
            var vanity = new ConfigAsset { Type = "VanityItemConfig" };
            vanity.Data.Add("Available", "kDefault").Add("Category", "kDefaultItem")
                .Add("ConduitOverrideList", L(new JObj().Add("ConduitOverride", new JObj().Add("Conduit", new JObj().Add("AssetPath", conduit).Add("Autoload", false)))))
                .Add("ModelList", L(new JObj().Add("BodyType", "kAll").Add("Model", new JObj().Add("AssetPath", s.MainModel).Add("Autoload", false)).Add("ModelInnerLayer", new JObj().Add("Autoload", false))))
                .Add("Name", id).Add("PartType", "kTypeBareTorsoAndArms")
                .Add("ShaderUpdater", new JObj().Add("Type", "SkinShaderUpdaterPrius"))
                .Add("SwitchGroupList", L(new JObj().Add("SwitchGroup", new JObj().Add("SwitchGroupName", "SpiderHero_Vanity").Add("SwitchGroupValue", "Default"))));
            if (s.BlackWebs) vanity.Data.Add("ForceBlackWebs", true);
            if (s.TentacleTraversal) vanity.Data.Add("ForceTentacleTraversal", true);

            var varGroup = new ConfigAsset { Type = "VanityVariantGroupItemConfig" };
            varGroup.Data.Add("ItemLoadoutConfig", new JObj().Add("AssetPath", varGroupLoadoutPath).Add("Autoload", false)).Add("Name", "suit_" + id + "_var_group");

            return new List<KeyValuePair<string, ConfigAsset>> {
                new KeyValuePair<string, ConfigAsset>(rewardPath, reward), new KeyValuePair<string, ConfigAsset>(loadoutPath, loadout),
                new KeyValuePair<string, ConfigAsset>(vanityPath, vanity), new KeyValuePair<string, ConfigAsset>(varGroupPath, varGroup) };
        }

        static void Str(BinaryWriter w, string s)
        {
            var b = Encoding.UTF8.GetBytes(s ?? "");
            if (b.Length > 255) throw new InvalidOperationException("Text too long for a .suit (255 bytes at most): " + s);
            w.Write((byte)b.Length); w.Write(b);
        }
        static void Align16(Stream s) { while (s.Position % 16 != 0) s.WriteByte(0); }

        /// <summary>Writes the .suit. progress is called with a 0..1 fraction.</summary>
        public static void Write(string outPath, SuitSpec spec, Action<double> progress = null)
        {
            var assets = new List<SuitAsset>();
            foreach (var c in Configs(spec))
            {
                byte[] d = c.Value.Dat1();
                assets.Add(new SuitAsset { Span = 0, Path = c.Key, Id = Hashes.AssetId(c.Key), Data = d, Header = ConfigAsset.Header(d.Length) });
            }
            assets.AddRange(spec.Assets);
            var seen = new HashSet<string>();
            foreach (var a in assets) if (!seen.Add(a.Span + ":" + a.Id.ToString("X16"))) throw new InvalidOperationException("Two files ended up with the same asset path: " + a.Path);
            assets.Sort((x, y) => x.Span != y.Span ? x.Span - y.Span : x.Id.CompareTo(y.Id));

            var offsets = new uint[assets.Count]; long total = 0;
            for (int i = 0; i < assets.Count; i++)
            {
                long len = assets[i].Length;
                if (total + len > uint.MaxValue - 16) throw new InvalidOperationException("A .suit cannot hold more than 4 GB of assets.");
                offsets[i] = (uint)total; total = (total + len + 15) & ~15L;
            }
            using (var f = new FileStream(outPath, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
            {
                var dsar = new DsarWriter(f, total);
                var zero = new byte[16]; var chunk = new byte[1 << 20]; long done = 0;
                for (int i = 0; i < assets.Count; i++)
                {
                    var a = assets[i]; long len = a.Length;
                    if (a.Data != null) dsar.Write(a.Data, 0, a.Data.Length);
                    else using (var src = System.IO.File.OpenRead(a.File))
                    {
                        if (src.Length < a.RawOffset + a.RawLength) throw new IOException("File changed while packing: " + a.File);
                        src.Position = a.RawOffset; long left = a.RawLength;
                        while (left > 0) { int n = src.Read(chunk, 0, (int)Math.Min(chunk.Length, left)); if (n <= 0) throw new IOException("Could not read " + a.File); dsar.Write(chunk, 0, n); left -= n; }
                    }
                    int pad = (int)(((len + 15) & ~15L) - len); if (pad > 0) dsar.Write(zero, 0, pad);
                    done += len; if (progress != null && total > 0) progress(Math.Min(1.0, (double)done / total));
                }
                dsar.Finish();
                f.Position = f.Length; Align16(f);
                f.Write(new byte[1024], 0, 1024); Align16(f);
                long payloadStart = f.Position;
                var w = new BinaryWriter(f);
                Str(w, spec.Id); Str(w, spec.ModName); Str(w, spec.Author); Str(w, spec.SuitName); Str(w, spec.Icon); Align16(f);
                var spans = new List<KeyValuePair<byte, uint>>();
                foreach (var a in assets) { if (spans.Count > 0 && spans[spans.Count - 1].Key == a.Span) spans[spans.Count - 1] = new KeyValuePair<byte, uint>(a.Span, spans[spans.Count - 1].Value + 1); else spans.Add(new KeyValuePair<byte, uint>(a.Span, 1)); }
                // Suit Tool starts counting at span 0 even when the first asset is in another span; with a config always in span 0 the result is the same
                w.Write((byte)spans.Count); foreach (var sp in spans) { w.Write(sp.Key); w.Write(sp.Value); }
                Align16(f);
                for (int i = 0; i < assets.Count; i++) { w.Write(assets[i].Id); w.Write(offsets[i]); w.Write((uint)assets[i].Length); }
                foreach (var a in assets) { w.Write((byte)Len(a.Header)); w.Write((byte)Len(a.Meta)); }
                Align16(f);
                foreach (var a in assets) if (Len(a.Header) > 0) w.Write(a.Header);
                foreach (var a in assets) if (Len(a.Meta) > 0) w.Write(a.Meta);
                Align16(f);
                long payloadEnd = f.Position;
                var ms = new MemoryStream(); var hw = new BinaryWriter(ms);
                hw.Write(0x54495553u); hw.Write((uint)(payloadEnd - payloadStart)); hw.Write((byte)1); hw.Write((byte)1); hw.Write((byte)0); hw.Write((byte)0); hw.Write((uint)assets.Count);
                var header = ms.ToArray();
                for (int i = 0; i < 16; i++) header[i] ^= dsar.First16[i];
                w.Write(header);
            }
        }
        static int Len(byte[] b)
        {
            if (b == null) return 0;
            if (b.Length > 255) throw new InvalidOperationException("Asset header too long for a .suit");
            return b.Length;
        }
    }
}
