// Turns a dropped folder of exported assets into the list of assets for a suit: which file is which asset,
// what format each one is in, what they refer to, and whether the result can work in Spider-Man 2.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SuitExport
{
    public enum AssetKind { Model, Material, Texture, Config, Other }
    public enum AssetFormat { SpiderMan2, Wolverine, Unknown }

    public class ScannedFile
    {
        public string File, Rel;            // full path, and path relative to the dropped folder
        public string AssetPath; public byte Span; public AssetKind Kind; public AssetFormat Format;
        public uint Dat1Type; public bool HasHeader, Fallback; public long Size; public string PathSource;   // how the asset path was found; Fallback = no real path known
        public List<string> References = new List<string>();
        public string Name { get { return Path.GetFileName(File); } }
    }

    public class SuitProject
    {
        public string Folder, Id, SuitName;
        public List<ScannedFile> Files = new List<ScannedFile>();
        public List<string> Skipped = new List<string>();
        public string MainModel, MaskModel, Icon;     // asset paths
        public bool SuitToolLayout; public string NameListFile;   // the hashes.txt the asset paths were looked up in, if any

        public IEnumerable<string> Models { get { return Files.Where(f => f.Kind == AssetKind.Model && f.Span == 0).Select(f => f.AssetPath).Distinct().OrderBy(x => x); } }
        public IEnumerable<string> Textures { get { return Files.Where(f => f.Kind == AssetKind.Texture && f.Span == 0).Select(f => f.AssetPath).Distinct().OrderBy(x => x); } }
        public int Count(AssetKind k) { return Files.Where(f => f.Kind == k).Select(f => f.AssetPath).Distinct().Count(); }
        public List<ScannedFile> InWolverineFormat { get { return Files.Where(f => f.Format == AssetFormat.Wolverine).ToList(); } }
        public bool Playable { get { return Files.Count > 0 && Files.All(f => f.Format != AssetFormat.Wolverine) && !string.IsNullOrEmpty(MainModel); } }

        /// <summary>Changes the suit id. Files whose real asset path is unknown live under suits/&lt;id&gt;/ and move with it.</summary>
        public void SetId(string id)
        {
            if (id == Id) return;
            string from = "suits/" + Id + "/", to = "suits/" + id + "/";
            Func<string, string> mv = s => !string.IsNullOrEmpty(s) && s.StartsWith(from, StringComparison.Ordinal) ? to + s.Substring(from.Length) : s;
            foreach (var f in Files) if (f.Fallback) { f.AssetPath = mv(f.AssetPath); f.PathSource = "not in any name list, placed under " + to; }
            MainModel = mv(MainModel); MaskModel = mv(MaskModel); Icon = mv(Icon); Id = id;
        }

        /// <summary>Asset paths that the packed files point at but that are not in the folder.</summary>
        public List<string> MissingReferences()
        {
            var have = new HashSet<string>(Files.Select(f => Hashes.Normalize(f.AssetPath)));
            var miss = new SortedSet<string>(StringComparer.Ordinal);
            foreach (var f in Files) foreach (var r in f.References) { string n = Hashes.Normalize(r); if (!have.Contains(n)) miss.Add(n); }
            return miss.ToList();
        }
    }

    public static class Scanner
    {
        // DAT1 type ids. Spider-Man 2's texture and config ids are the ones Overstrike checks for; the Wolverine ones are
        // what this build's own files carry.
        const uint WOLV_MODEL = 0x648DBC7B, WOLV_MATERIAL = 0xE7D1F09E, WOLV_TEXTURE = 0x8743FC2F, WOLV_ZIVA = 0x88C51E5D;
        const uint SM2_TEXTURE = 0x3E7886C8, SM2_CONFIG = 0x35F7AFA5;
        static readonly Regex PathLike = new Regex(@"[A-Za-z0-9_][A-Za-z0-9_ .\-/\\()]*[/\\][A-Za-z0-9_ .\-/\\()]+\.[a-z0-9_]{2,16}", RegexOptions.Compiled);
        static readonly string[] AssetExts = { ".texture", ".material", ".materialgraph", ".model", ".config", ".zrt", ".animclip", ".actor", ".conduit", ".visualeffect" };

        public static string MakeId(string folderName)
        {
            string s = Regex.Replace(folderName.ToLowerInvariant(), "[^a-z0-9]+", "_").Trim('_');
            if (s.StartsWith("hero_")) s = s.Substring(5);
            if (s.Length == 0) s = "suit";
            if (s.Length > 40) s = s.Substring(0, 40).Trim('_');
            return s;
        }
        public static string MakeName(string id)
        {
            return System.Globalization.CultureInfo.InvariantCulture.TextInfo.ToTitleCase(id.Replace('_', ' '));
        }

        static AssetKind KindOf(string lower)
        {
            if (lower.EndsWith(".texture")) return AssetKind.Texture;
            if (lower.EndsWith(".material")) return AssetKind.Material;
            if (lower.EndsWith(".model") || Regex.IsMatch(lower, @"\.model\.\d$")) return AssetKind.Model;
            if (lower.EndsWith(".config")) return AssetKind.Config;
            return AssetKind.Other;
        }

        /// <summary>Asset paths written inside a file (string table and data), e.g. the textures a material uses.</summary>
        static List<string> ReadReferences(SuitAsset a, AssetKind kind)
        {
            var res = new List<string>();
            try
            {
                int want = kind == AssetKind.Model ? 4 << 20 : 2 << 20;      // models keep their names in the header part
                byte[] b = a.Peek((int)Math.Min(a.Length, want));
                if (b.Length < 16 || BitConverter.ToUInt32(b, 0) != 0x44415431) return res;
                string text = Encoding.GetEncoding(28591).GetString(b);
                var seen = new HashSet<string>();
                foreach (Match m in PathLike.Matches(text))
                {
                    string v = m.Value; string low = v.ToLowerInvariant();
                    if (!AssetExts.Any(low.EndsWith)) continue;
                    if (low.Length > 260) continue;
                    if (seen.Add(Hashes.Normalize(v))) res.Add(v);
                }
            }
            catch (IOException) { }
            return res;
        }

        public static SuitProject Scan(string folder, NameList names)
        {
            folder = Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            var p = new SuitProject { Folder = folder, Id = MakeId(Path.GetFileName(folder)) };
            p.SuitName = MakeName(p.Id);
            p.NameListFile = names == null ? null : names.Source;
            var all = Directory.GetFiles(folder, "*", SearchOption.AllDirectories).OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
            // Suit Tool project layout: top-level folders named 0, 1, ... hold the assets of that span
            var spanDirs = Directory.GetDirectories(folder).Where(d => Regex.IsMatch(Path.GetFileName(d), @"^\d{1,3}$")).ToList();
            p.SuitToolLayout = spanDirs.Count > 0 && spanDirs.Any(d => Directory.GetFiles(d, "*", SearchOption.AllDirectories).Length > 0);

            var loose = new List<ScannedFile>();
            foreach (var file in all)
            {
                string rel = file.Substring(folder.Length + 1).Replace('\\', '/'); string low = rel.ToLowerInvariant();
                string first = rel.Split('/')[0];
                if (low.EndsWith(".blender.model")) { p.Skipped.Add(rel + "  (a Blender import copy, not a game file)"); continue; }
                if (first.Equals("out", StringComparison.OrdinalIgnoreCase) || low.EndsWith(".suit") || low.EndsWith(".suit_style") || low.EndsWith(".suit_project") || low.EndsWith("_report.txt")) { p.Skipped.Add(rel + "  (output of a suit tool)"); continue; }
                if (new FileInfo(file).Length == 0) { p.Skipped.Add(rel + "  (empty file)"); continue; }
                var sf = new ScannedFile { File = file, Rel = rel, Size = new FileInfo(file).Length };
                if (p.SuitToolLayout)
                {
                    if (!Regex.IsMatch(first, @"^\d{1,3}$") || rel.IndexOf('/') < 0) { p.Skipped.Add(rel + "  (outside the 0/, 1/ ... folders)"); continue; }
                    sf.Span = byte.Parse(first); sf.AssetPath = rel.Substring(first.Length + 1); sf.PathSource = "folder layout";
                    sf.Kind = KindOf(sf.AssetPath.ToLowerInvariant());
                    p.Files.Add(sf);
                }
                else
                {
                    string name = Path.GetFileName(rel), nlow = name.ToLowerInvariant();
                    if (nlow.EndsWith(".hd.texture")) { sf.Span = 1; name = name.Substring(0, name.Length - ".hd.texture".Length) + ".texture"; }
                    else { var m = Regex.Match(nlow, @"\.model\.(\d)$"); if (m.Success) { sf.Span = byte.Parse(m.Groups[1].Value); name = name.Substring(0, name.Length - 2); } }
                    sf.Kind = KindOf(name.ToLowerInvariant());
                    if (sf.Kind == AssetKind.Other && !AssetExts.Any(name.ToLowerInvariant().EndsWith)) { p.Skipped.Add(rel + "  (not a game asset type this tool knows)"); continue; }
                    sf.AssetPath = name;     // file name for now; the real path is worked out below
                    loose.Add(sf); p.Files.Add(sf);
                }
            }

            // what each file is, and what it refers to
            foreach (var sf in p.Files)
            {
                var a = SuitAsset.FromFile(sf.File, sf.Span, sf.AssetPath);
                sf.HasHeader = a.Header != null && a.Header.Length > 0;
                var head = a.Peek(8);
                sf.Dat1Type = head.Length >= 8 && BitConverter.ToUInt32(head, 0) == 0x44415431 ? BitConverter.ToUInt32(head, 4) : 0;
                if (sf.Dat1Type == 0 && sf.HasHeader && a.Header.Length >= 4) sf.Dat1Type = BitConverter.ToUInt32(a.Header, 0);
                if (sf.Dat1Type == WOLV_MODEL || sf.Dat1Type == WOLV_MATERIAL || sf.Dat1Type == WOLV_TEXTURE || sf.Dat1Type == WOLV_ZIVA) sf.Format = AssetFormat.Wolverine;
                else if (sf.Dat1Type == SM2_TEXTURE || sf.Dat1Type == SM2_CONFIG) sf.Format = AssetFormat.SpiderMan2;
                else sf.Format = AssetFormat.Unknown;
                if (sf.Span == 0 && (sf.Kind == AssetKind.Material || sf.Kind == AssetKind.Model)) sf.References = ReadReferences(a, sf.Kind);
            }

            if (!p.SuitToolLayout)
            {
                // 1. paths that the dropped files themselves mention (a material names its textures, a model its materials)
                var mentioned = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
                foreach (var sf in p.Files) foreach (var r in sf.References)
                {
                    string bn = r.Replace('\\', '/'); bn = bn.Substring(bn.LastIndexOf('/') + 1);
                    List<string> l; if (!mentioned.TryGetValue(bn, out l)) mentioned[bn] = l = new List<string>();
                    string n = Hashes.Normalize(r); if (!l.Contains(n)) l.Add(n);
                }
                string hint = Path.GetFileName(folder).ToLowerInvariant();
                foreach (var sf in loose)
                {
                    string bn = sf.AssetPath; List<string> l;
                    var cands = new List<string>(); string src = null;
                    if (mentioned.TryGetValue(bn, out l)) { cands.AddRange(l); src = "named by another file in the folder"; }
                    if (cands.Count == 0 && names != null) { cands.AddRange(names.Lookup(bn)); if (cands.Count > 0) src = "asset name list"; }
                    if (cands.Count > 0)
                    {
                        // several assets can share a file name; prefer the one whose path fits where the file sits
                        string relDir = Path.GetDirectoryName(sf.Rel).Replace('\\', '/').ToLowerInvariant();
                        sf.AssetPath = cands.OrderByDescending(c => (c.Contains("/" + hint + "/") ? 2 : 0) + (relDir.Length > 0 && c.Contains("/" + relDir + "/") ? 1 : 0)).First();
                        sf.PathSource = src + (cands.Count > 1 ? " (" + cands.Count + " candidates)" : "");
                    }
                    else
                    {
                        string sub = sf.Kind == AssetKind.Model ? "models" : sf.Kind == AssetKind.Material ? "materials" : sf.Kind == AssetKind.Texture ? "textures" : "other";
                        sf.AssetPath = "suits/" + p.Id + "/" + sub + "/" + bn.ToLowerInvariant(); sf.Fallback = true; sf.PathSource = "not in any name list, placed under suits/" + p.Id + "/";
                    }
                }
                // a span-1 half always belongs to the same asset as its span-0 file
                foreach (var hd in loose.Where(f => f.Span > 0))
                {
                    string b0 = Regex.Replace(hd.Rel, @"\.hd\.texture$", ".texture", RegexOptions.IgnoreCase); b0 = Regex.Replace(b0, @"\.model\.\d$", ".model.0", RegexOptions.IgnoreCase);
                    var main = loose.FirstOrDefault(f => f.Span == 0 && f.Rel.Equals(b0, StringComparison.OrdinalIgnoreCase));
                    if (main != null) { hd.AssetPath = main.AssetPath; hd.PathSource = main.PathSource; hd.Fallback = main.Fallback; }
                }
            }
            // raw halves (HD texture data, streamed model data) are in whatever format their main file is in
            foreach (var hd in p.Files.Where(f => f.Dat1Type == 0))
            {
                var main = p.Files.FirstOrDefault(f => f.Span == 0 && f.Dat1Type != 0 && Hashes.Normalize(f.AssetPath) == Hashes.Normalize(hd.AssetPath));
                if (main != null) hd.Format = main.Format;
            }

            // duplicates: two files claiming one asset in one span
            var dup = p.Files.GroupBy(f => f.Span + ":" + Hashes.Normalize(f.AssetPath)).Where(g => g.Count() > 1).ToList();
            foreach (var g in dup) foreach (var extra in g.OrderByDescending(f => f.Size).Skip(1)) { p.Files.Remove(extra); p.Skipped.Add(extra.Rel + "  (same asset as " + g.OrderByDescending(f => f.Size).First().Rel + ")"); }

            PickDefaults(p);
            return p;
        }

        static void PickDefaults(SuitProject p)
        {
            var models = p.Files.Where(f => f.Kind == AssetKind.Model && f.Span == 0).ToList();
            Func<ScannedFile, long> total = m => p.Files.Where(f => f.AssetPath == m.AssetPath).Sum(f => f.Size);
            Func<ScannedFile, bool> part = m => Regex.IsMatch(m.Name.ToLowerInvariant(), "mask|head|hair|eye|teeth|claw|lod|_igmodel_|physique");
            var main = models.Where(m => !part(m)).OrderBy(m => m.Rel.Count(c => c == '/')).ThenByDescending(total).FirstOrDefault()
                       ?? models.Where(m => !m.Name.ToLowerInvariant().Contains("mask")).OrderByDescending(total).FirstOrDefault() ?? models.FirstOrDefault();
            p.MainModel = main == null ? "" : main.AssetPath;
            var mask = models.Where(m => m != main && m.Name.ToLowerInvariant().Contains("mask")).OrderBy(m => m.Rel.Count(c => c == '/')).FirstOrDefault();
            p.MaskModel = mask == null ? "" : mask.AssetPath;
            var tex = p.Files.Where(f => f.Kind == AssetKind.Texture && f.Span == 0).ToList();
            Func<string, ScannedFile> find = pat => tex.FirstOrDefault(t => Regex.IsMatch(t.Name.ToLowerInvariant(), pat));
            var icon = find("icon") ?? find(@"(torso|body|chest).*_c\.texture$") ?? find(@"_c\.texture$") ?? tex.FirstOrDefault();
            p.Icon = icon == null ? "" : icon.AssetPath;
        }

        static string N(int n, string what) { return n + " " + what + (n == 1 ? "" : "s"); }
        public static string Mb(long bytes) { return bytes >= 1 << 20 ? (bytes / 1048576.0).ToString("0.#") + " MB" : (bytes / 1024.0).ToString("0.#") + " KB"; }

        /// <summary>Everything worth knowing about a project, in plain text.</summary>
        public static string Report(SuitProject p, IEnumerable<string> written = null)
        {
            var sb = new StringBuilder();
            sb.AppendLine(p.SuitName + "   (suit id: " + p.Id + ")");
            sb.AppendLine("Folder: " + p.Folder);
            if (!p.SuitToolLayout) sb.AppendLine("Asset names: " + (p.NameListFile ?? "no hashes.txt found next to this program or above the folder; files that nothing else names get a path under suits/" + p.Id + "/"));
            sb.AppendLine();
            sb.AppendLine("Main model: " + (string.IsNullOrEmpty(p.MainModel) ? "(none found - a suit needs one)" : p.MainModel));
            sb.AppendLine("Mask model: " + (string.IsNullOrEmpty(p.MaskModel) ? "(none)" : p.MaskModel));
            sb.AppendLine("Menu icon:  " + (string.IsNullOrEmpty(p.Icon) ? "(none)" : p.Icon));
            sb.AppendLine();
            sb.AppendLine("Packed: " + p.Files.Count + " files, " + Mb(p.Files.Sum(f => f.Size)) + "  =  " + N(p.Count(AssetKind.Model), "model") + ", " + N(p.Count(AssetKind.Material), "material") + ", " +
                          N(p.Count(AssetKind.Texture), "texture") + (p.Count(AssetKind.Other) + p.Count(AssetKind.Config) > 0 ? ", " + (p.Count(AssetKind.Other) + p.Count(AssetKind.Config)) + " other" : "") + ", plus 4 generated configs");
            sb.AppendLine();
            var wolv = p.InWolverineFormat;
            if (p.Playable)
            {
                sb.AppendLine("FORMAT CHECK: nothing here is in Marvel's Wolverine format.");
                var unknown = p.Files.Where(f => f.Format == AssetFormat.Unknown && f.Dat1Type != 0).Select(f => f.Dat1Type).Distinct().ToList();
                if (unknown.Count > 0) sb.AppendLine("  " + N(p.Files.Count(f => f.Format == AssetFormat.Unknown), "file") + " of a type this tool cannot confirm as Spider-Man 2's (type id " + string.Join(", ", unknown.Select(u => u.ToString("X8"))) + "), packed as they are.");
                sb.AppendLine("  This check only rules out Wolverine files. It does not prove the suit works in the game.");
                var noHeader = p.Files.Where(f => f.Span == 0 && f.Dat1Type != 0 && !f.HasHeader).ToList();
                if (noHeader.Count > 0) sb.AppendLine("  " + N(noHeader.Count, "file") + " without an STG header (e.g. " + noHeader[0].Rel + "). Export them with the STG header on, or the game gets no size information for them.");
            }
            else if (wolv.Count > 0)
            {
                sb.AppendLine("NOT PLAYABLE IN SPIDER-MAN 2 YET");
                sb.AppendLine("  " + wolv.Count + " of the " + p.Files.Count + " files are still in Marvel's Wolverine (i38, PS5) format:");
                foreach (var g in wolv.GroupBy(f => f.Kind)) { int n = g.Select(f => f.AssetPath).Distinct().Count(); sb.AppendLine("    " + n + " " + (g.Key == AssetKind.Other ? "other file" : g.Key.ToString().ToLowerInvariant()) + (n == 1 ? "" : "s")); }
                sb.AppendLine("  Spider-Man 2 will not load them. The .suit file itself is valid, and Overstrike will install it, but the suit");
                sb.AppendLine("  will not appear correctly in the game until these are replaced by Spider-Man 2 format files:");
                sb.AppendLine("    models     need Peter's / Miles's skeleton and the older geometry layout (rig to hero_spiderman_advanced.model");
                sb.AppendLine("               in Blender with the Luna add-on, export, and drop the exported folder here instead)");
                sb.AppendLine("    materials  use shaders that only exist in Wolverine; they have to be rebuilt on a Spider-Man 2 suit material");
                sb.AppendLine("    textures   are in the PS5 block layout; they have to be rewritten in the PC layout");
            }
            else if (string.IsNullOrEmpty(p.MainModel)) sb.AppendLine("NOT A SUIT YET: there is no .model file in the folder.");
            sb.AppendLine();
            var miss = p.MissingReferences();
            if (miss.Count > 0)
            {
                sb.AppendLine("Used by the packed files but not in the folder (" + miss.Count + "). These must already exist in the game, or be added to the folder:");
                foreach (var g in miss.GroupBy(m => Path.GetExtension(m)).OrderByDescending(g => g.Count()))
                {
                    sb.AppendLine("  " + g.Count() + " x " + g.Key);
                    foreach (var m in g.Take(12)) sb.AppendLine("      " + m);
                    if (g.Count() > 12) sb.AppendLine("      ... and " + (g.Count() - 12) + " more");
                }
                sb.AppendLine();
            }
            sb.AppendLine("Files and the asset each one becomes:");
            foreach (var f in p.Files.OrderBy(f => f.Kind).ThenBy(f => f.AssetPath).ThenBy(f => f.Span))
                sb.AppendLine("  [" + f.Span + "] " + f.AssetPath + "   <-  " + f.Rel + "  (" + Mb(f.Size) + ", " + (f.Format == AssetFormat.Wolverine ? "Wolverine format" : f.Format == AssetFormat.SpiderMan2 ? "Spider-Man 2 format" : "type not recognised") + "; path: " + f.PathSource + ")");
            if (p.Skipped.Count > 0)
            {
                sb.AppendLine(); sb.AppendLine("Left out (" + p.Skipped.Count + "):");
                foreach (var s in p.Skipped) sb.AppendLine("  " + s);
            }
            if (written != null)
            {
                sb.AppendLine(); sb.AppendLine("Written:");
                foreach (var w in written) sb.AppendLine("  " + w);
            }
            return sb.ToString();
        }

        /// <summary>Builds the suit description for one hero from a scanned project.</summary>
        public static SuitSpec Spec(SuitProject p, bool peter, string author, bool bothHeroes)
        {
            string id = p.Id + (bothHeroes ? (peter ? "_peter" : "_miles") : "");
            var spec = new SuitSpec
            {
                Id = id, Peter = peter, Author = author ?? "", SuitName = p.SuitName,
                ModName = p.SuitName + (bothHeroes ? (peter ? " (Peter)" : " (Miles)") : ""),
                MainModel = p.MainModel, MaskModel = p.MaskModel ?? "", Icon = p.Icon ?? ""
            };
            foreach (var f in p.Files) spec.Assets.Add(SuitAsset.FromFile(f.File, f.Span, f.AssetPath));
            return spec;
        }
    }

    /// <summary>The "id,path,count" asset name lists the extraction tools use (hashes.txt); only file names are indexed.
    /// Several lists can be combined: the first one that knows a file name answers.</summary>
    public class NameList
    {
        readonly List<string> files = new List<string>();
        readonly List<Dictionary<string, List<string>>> loaded = new List<Dictionary<string, List<string>>>();
        static readonly Dictionary<string, Dictionary<string, List<string>>> cache = new Dictionary<string, Dictionary<string, List<string>>>(StringComparer.OrdinalIgnoreCase);
        public string Source { get { return string.Join(" ; ", files); } }
        public NameList(params string[] paths) { files.AddRange(paths); }

        /// <summary>Every hashes.txt in the given folders, in that order (at most three).</summary>
        public static NameList Find(params string[] folders)
        {
            var found = new List<string>();
            foreach (var d in folders)
            {
                if (string.IsNullOrEmpty(d)) continue;
                foreach (var n in new[] { "hashes.txt", "asset_hashes.txt" })
                {
                    string p = Path.Combine(d, n);
                    try { if (File.Exists(p) && new FileInfo(p).Length >= 1000 && !found.Contains(p, StringComparer.OrdinalIgnoreCase) && found.Count < 3) found.Add(p); }
                    catch (IOException) { } catch (UnauthorizedAccessException) { }
                }
            }
            return found.Count == 0 ? null : new NameList(found.ToArray());
        }
        /// <summary>The folder itself and the folders above it, nearest first.</summary>
        public static string[] Above(string folder, int levels)
        {
            var l = new List<string>(); string d = folder;
            for (int i = 0; i <= levels && !string.IsNullOrEmpty(d); i++) { l.Add(d); try { d = Path.GetDirectoryName(d); } catch (ArgumentException) { break; } }
            return l.ToArray();
        }
        static Dictionary<string, List<string>> Load(string file)
        {
            lock (cache)
            {
                Dictionary<string, List<string>> byName;
                if (cache.TryGetValue(file, out byName)) return byName;
                byName = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
                try
                {
                    using (var r = new StreamReader(file, Encoding.GetEncoding(28591)))
                    {
                        string line;
                        while ((line = r.ReadLine()) != null)
                        {
                            int a = line.IndexOf(','); if (a < 0) continue;
                            int b = line.LastIndexOf(','); if (b <= a) continue;
                            string path = line.Substring(a + 1, b - a - 1); if (path.Length == 0) continue;
                            int s = Math.Max(path.LastIndexOf('/'), path.LastIndexOf('\\'));
                            string bn = path.Substring(s + 1);
                            List<string> l; if (!byName.TryGetValue(bn, out l)) byName[bn] = l = new List<string>(1);
                            string n = Hashes.Normalize(path); if (!l.Contains(n)) l.Add(n);
                        }
                    }
                }
                catch (IOException) { } catch (UnauthorizedAccessException) { }
                cache[file] = byName; return byName;
            }
        }
        public List<string> Lookup(string fileName)
        {
            lock (this)
            {
                for (int i = 0; i < files.Count; i++)
                {
                    if (loaded.Count <= i) loaded.Add(Load(files[i]));     // a later list is only read when the earlier ones do not know the name
                    List<string> l; if (loaded[i].TryGetValue(fileName, out l)) return l;
                }
            }
            return new List<string>();
        }
    }
}
