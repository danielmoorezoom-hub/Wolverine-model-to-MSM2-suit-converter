#!/bin/bash
# Builds against the .NET Framework 4.5 reference assemblies (-sdk:4.5-api), NOT Mono's own libraries:
# a program compiled against Mono's libraries can start under Mono and still fail on Windows.
set -e
cd "$(dirname "$0")"
mcs -sdk:4.5-api -target:winexe -win32icon:app.ico -out:SuitExporter.exe -r:System.Windows.Forms -r:System.Drawing SuitFormat.cs SuitScan.cs Exporter.cs ExporterForm.cs Converter.cs
echo built
