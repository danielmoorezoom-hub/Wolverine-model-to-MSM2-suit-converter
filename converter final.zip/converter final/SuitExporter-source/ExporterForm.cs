// The window: drop folders, check what was found, export one .suit per hero.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SuitExport
{
    public class ExporterForm : Form
    {
        readonly List<SuitProject> projects = new List<SuitProject>();
        readonly Queue<string> toScan = new Queue<string>();
        readonly BackgroundWorker scanner = new BackgroundWorker(), exporter = new BackgroundWorker { WorkerReportsProgress = true };
        readonly string exeDir = Path.GetDirectoryName(Application.ExecutablePath);

        ListView list; TextBox idBox, nameBox, report, authorBox, outBox; ComboBox mainBox, maskBox, iconBox;
        CheckBox peterBox, milesBox; Button convBtn, exportBtn, removeBtn, clearBtn, addBtn, browseBtn, openBtn; ProgressBar bar; Label status, idNote;
        TableLayoutPanel detail; bool loading; string lastExport = "";
        /// <summary>Test switches: export as soon as scanning ends, show no dialogs, close when done.</summary>
        public bool AutoExport, Quiet, ExitWhenDone; public int ExitCode;

        const string None = "(none)";

        public ExporterForm(IEnumerable<string> startFolders)
        {
            Text = "Suit Exporter " + Exporter.Version + "  -  Wolverine suit folders to Marvel's Spider-Man 2 .suit";
            Font = new Font("Segoe UI", 9f); ClientSize = new Size(1060, 760); MinimumSize = new Size(900, 640);
            StartPosition = FormStartPosition.CenterScreen;
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch (Exception) { }

            var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 5, Padding = new Padding(8) };
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 132));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 122));
            root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 104));
            Controls.Add(root);

            // --- top: what to do, and the folder buttons
            var top = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 1, Margin = new Padding(0) };
            top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            for (int i = 0; i < 3; i++) top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112));
            var hint = new Label
            {
                Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft,
                Text = "Drop suit folders anywhere on this window. Each folder becomes one suit.\nWolverine folders are converted to Spider-Man 2 files on export (Blender does the model work; see Conversion...)."
            };
            hint.Font = new Font(Font.FontFamily, 9.75f);
            addBtn = Btn("Add folder...", (s, e) => PickFolder());
            removeBtn = Btn("Remove", (s, e) => RemoveSelected());
            clearBtn = Btn("Clear list", (s, e) => { projects.Clear(); RefreshList(null); });
            top.Controls.Add(hint, 0, 0); top.Controls.Add(addBtn, 1, 0); top.Controls.Add(removeBtn, 2, 0); top.Controls.Add(clearBtn, 3, 0);
            root.Controls.Add(top, 0, 0);

            // --- the folders
            list = new ListView { Dock = DockStyle.Fill, View = View.Details, FullRowSelect = true, HideSelection = false, MultiSelect = true, GridLines = false };
            list.Columns.Add("Suit", 190); list.Columns.Add("Folder", 330); list.Columns.Add("Files", 50, HorizontalAlignment.Right);
            list.Columns.Add("Size", 76, HorizontalAlignment.Right); list.Columns.Add("Status", 380);
            list.SelectedIndexChanged += (s, e) => ShowSelected();
            list.KeyDown += (s, e) => { if (e.KeyCode == Keys.Delete) RemoveSelected(); };
            root.Controls.Add(list, 0, 1);

            // --- the selected suit
            var box = new GroupBox { Dock = DockStyle.Fill, Text = "Selected suit", Padding = new Padding(8, 4, 8, 4) };
            detail = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, RowCount = 3 };
            detail.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110)); detail.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            detail.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110)); detail.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
            for (int i = 0; i < 3; i++) detail.RowStyles.Add(new RowStyle(SizeType.Absolute, 30));
            idBox = new TextBox { Dock = DockStyle.Fill, MaxLength = 48 }; nameBox = new TextBox { Dock = DockStyle.Fill, MaxLength = 80 };
            mainBox = Combo(); maskBox = Combo(); iconBox = Combo();
            idNote = new Label { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, ForeColor = Color.Firebrick };
            detail.Controls.Add(Lbl("Suit id"), 0, 0); detail.Controls.Add(idBox, 1, 0); detail.Controls.Add(Lbl("Name in game"), 2, 0); detail.Controls.Add(nameBox, 3, 0);
            detail.Controls.Add(Lbl("Main model"), 0, 1); detail.Controls.Add(mainBox, 1, 1); detail.Controls.Add(Lbl("Mask model"), 2, 1); detail.Controls.Add(maskBox, 3, 1);
            detail.Controls.Add(Lbl("Menu icon"), 0, 2); detail.Controls.Add(iconBox, 1, 2); detail.Controls.Add(idNote, 2, 2); detail.SetColumnSpan(idNote, 2);
            idBox.TextChanged += (s, e) => Edit(p =>
            {
                string v = idBox.Text.Trim();
                if (System.Text.RegularExpressions.Regex.IsMatch(v, "^[a-z0-9_]{1,48}$")) { p.SetId(v); idNote.Text = ""; }
                else idNote.Text = "Suit id: lower-case letters, digits and _ only.";
            });
            nameBox.TextChanged += (s, e) => Edit(p => p.SuitName = nameBox.Text.Trim());
            mainBox.SelectedIndexChanged += (s, e) => Edit(p => p.MainModel = Picked(mainBox));
            maskBox.SelectedIndexChanged += (s, e) => Edit(p => p.MaskModel = Picked(maskBox));
            iconBox.SelectedIndexChanged += (s, e) => Edit(p => p.Icon = Picked(iconBox));
            box.Controls.Add(detail); root.Controls.Add(box, 0, 2);

            // --- what was found
            report = new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, WordWrap = false, BackColor = SystemColors.Window };
            report.Font = new Font(FontFamily.GenericMonospace, 9f);
            root.Controls.Add(report, 0, 3);

            // --- export
            var bottom = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 6, RowCount = 3, Margin = new Padding(0, 4, 0, 0) };
            bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 70)); bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60)); bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80));
            bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100)); bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 112));
            for (int i = 0; i < 3; i++) bottom.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
            authorBox = new TextBox { Dock = DockStyle.Fill, MaxLength = 60 };
            peterBox = new CheckBox { Text = "Peter", Checked = true, Dock = DockStyle.Fill }; milesBox = new CheckBox { Text = "Miles", Checked = true, Dock = DockStyle.Fill };
            outBox = new TextBox { Dock = DockStyle.Fill };
            browseBtn = Btn("Browse...", (s, e) => { using (var d = new FolderBrowserDialog { Description = "Where to save the exported suits", SelectedPath = Directory.Exists(outBox.Text) ? outBox.Text : exeDir }) if (d.ShowDialog(this) == DialogResult.OK) outBox.Text = d.SelectedPath; });
            openBtn = Btn("Open folder", (s, e) => OpenOutput());
            convBtn = Btn("Conversion...", (s, e) => EditConversion());
            exportBtn = Btn("Export .suit files", (s, e) => StartExport()); exportBtn.Font = new Font(Font, FontStyle.Bold);
            bar = new ProgressBar { Dock = DockStyle.Fill, Maximum = 1000, Margin = new Padding(3, 7, 3, 7) };
            status = new Label { Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, AutoEllipsis = true };
            bottom.Controls.Add(Lbl("Author"), 0, 0); bottom.Controls.Add(authorBox, 1, 0); bottom.Controls.Add(Lbl("Suits for"), 2, 0); bottom.Controls.Add(peterBox, 3, 0); bottom.Controls.Add(milesBox, 4, 0); bottom.Controls.Add(convBtn, 5, 0);
            bottom.Controls.Add(Lbl("Save to"), 0, 1); bottom.Controls.Add(outBox, 1, 1); bottom.SetColumnSpan(outBox, 3); bottom.Controls.Add(browseBtn, 4, 1); bottom.Controls.Add(openBtn, 5, 1);
            bottom.Controls.Add(status, 0, 2); bottom.SetColumnSpan(status, 2); bottom.Controls.Add(bar, 2, 2); bottom.SetColumnSpan(bar, 3); bottom.Controls.Add(exportBtn, 5, 2);
            root.Controls.Add(bottom, 0, 4);

            outBox.Text = Path.Combine(exeDir, "Suits");
            LoadSettings(); conv.Guess(exeDir);

            // dropping works on every part of the window
            AllowDrops(this);

            scanner.DoWork += (s, e) =>
            {
                string f = (string)e.Argument;
                var names = NameList.Find(NameList.Above(f, 6).Concat(new[] { exeDir }).ToArray());
                e.Result = Scanner.Scan(f, names);
            };
            scanner.RunWorkerCompleted += ScanDone;
            exporter.DoWork += ExportWork;
            exporter.ProgressChanged += (s, e) => { bar.Value = Math.Max(0, Math.Min(1000, e.ProgressPercentage)); status.Text = e.UserState as string ?? status.Text; };
            exporter.RunWorkerCompleted += ExportDone;

            ShowSelected(); Busy(false);
            Shown += (s, e) => { foreach (var f in startFolders) AddPath(f); if (!scanner.IsBusy && toScan.Count == 0 && AutoExport) Finish(2); };
            FormClosing += (s, e) => SaveSettings();
        }

        // ---------- small helpers
        Button Btn(string text, EventHandler click) { var b = new Button { Text = text, Dock = DockStyle.Fill, Margin = new Padding(3, 2, 3, 2) }; b.Click += click; return b; }
        static Label Lbl(string text) { return new Label { Text = text, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft }; }
        static ComboBox Combo() { return new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList, DropDownWidth = 620 }; }
        static string Picked(ComboBox c) { string v = c.SelectedItem as string; return v == null || v == None ? "" : v; }
        void AllowDrops(Control c)
        {
            c.AllowDrop = true;
            c.DragEnter += (s, e) => e.Effect = !Working && e.Data.GetDataPresent(DataFormats.FileDrop) ? DragDropEffects.Copy : DragDropEffects.None;
            c.DragDrop += (s, e) => { var files = e.Data.GetData(DataFormats.FileDrop) as string[]; if (files != null && !exporter.IsBusy) foreach (var f in files) AddPath(f); };
            foreach (Control k in c.Controls) AllowDrops(k);
        }
        bool Working { get { return exporter.IsBusy; } }
        SuitProject Selected { get { return list.SelectedItems.Count > 0 ? list.SelectedItems[0].Tag as SuitProject : null; } }

        string SettingsFile { get { return Path.Combine(exeDir, "SuitExporter-settings.txt"); } }
        readonly ConvertSettings conv = new ConvertSettings();
        /// <summary>Conversion settings from the settings file, with the usual places filled in.</summary>
        public static ConvertSettings LoadConvert(string exeDir)
        {
            var c = new ConvertSettings();
            try
            {
                string f = Path.Combine(exeDir, "SuitExporter-settings.txt");
                if (File.Exists(f)) foreach (var line in File.ReadAllLines(f)) { int i = line.IndexOf('='); if (i > 0 && ConvertSettings.Keys.Contains(line.Substring(0, i))) c.Set(line.Substring(0, i), line.Substring(i + 1)); }
            }
            catch (IOException) { } catch (UnauthorizedAccessException) { }
            c.Guess(exeDir); return c;
        }
        void EditConversion()
        {
            conv.Guess(exeDir);
            using (var f = new Form { Text = "Conversion to Spider-Man 2", ClientSize = new Size(820, 540), FormBorderStyle = FormBorderStyle.FixedDialog, MaximizeBox = false, MinimizeBox = false, StartPosition = FormStartPosition.CenterParent, Font = Font })
            {
                var t = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, RowCount = 13, Padding = new Padding(8) };
                t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190)); t.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); t.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 90));
                var rows = new[] {
                    new { K = "blender", L = "Blender 5 (blender.exe)", File = true, Filter = "blender.exe|blender.exe" },
                    new { K = "luna", L = "Luna Engine IO add-on folder", File = false, Filter = "" },
                    new { K = "peter_template", L = "Peter template .model", File = true, Filter = "Spider-Man 2 model|*.model" },
                    new { K = "miles_template", L = "Miles template .model", File = true, Filter = "Spider-Man 2 model|*.model" },
                    new { K = "sm2_textures", L = "Spider-Man 2 textures (optional)", File = false, Filter = "" },
                    new { K = "sm2_material", L = "Spider-Man 2 suit material", File = true, Filter = "Spider-Man 2 material|*.material" },
                    new { K = "wolverine_extracted", L = "Extracted Wolverine files (optional)", File = false, Filter = "" },
                    new { K = "wolverine_game", L = "Wolverine game folder (optional)", File = false, Filter = "" },
                    new { K = "hair_donor", L = "Hair donor model (strand hair)", File = true, Filter = "Spider-Man 2 model|*.model" },
                    new { K = "hair_colour", L = "Hair colour (optional, #rrggbb)", File = false, Filter = "" } };
                var boxes = new Dictionary<string, TextBox>();
                for (int i = 0; i < rows.Length; i++)
                {
                    var r = rows[i]; var tb = new TextBox { Dock = DockStyle.Fill, Text = conv.Get(r.K) }; boxes[r.K] = tb;
                    var b = new Button { Text = "Browse...", Dock = DockStyle.Fill };
                    b.Click += (s, e) =>
                    {
                        if (r.K == "hair_colour") { using (var d = new ColorDialog { FullOpen = true }) if (d.ShowDialog(f) == DialogResult.OK) tb.Text = "#" + d.Color.R.ToString("x2") + d.Color.G.ToString("x2") + d.Color.B.ToString("x2"); return; }
                        if (r.File) { using (var d = new OpenFileDialog { Filter = r.Filter, FileName = tb.Text }) if (d.ShowDialog(f) == DialogResult.OK) tb.Text = d.FileName; }
                        else using (var d = new FolderBrowserDialog { SelectedPath = Directory.Exists(tb.Text) ? tb.Text : "" }) if (d.ShowDialog(f) == DialogResult.OK) tb.Text = d.SelectedPath;
                    };
                    t.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
                    t.Controls.Add(Lbl(r.L), 0, i); t.Controls.Add(tb, 1, i); t.Controls.Add(b, 2, i);
                }
                var headBox = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList, Dock = DockStyle.Fill };
                headBox.Items.AddRange(new object[] { "Auto: leave out only on Logan's own suits (his face is under the mask)", "Keep: include the character's head (other characters)", "Skip: always leave head models out" });
                headBox.SelectedIndex = conv.Heads == "keep" ? 1 : conv.Heads == "skip" ? 2 : 0;
                t.RowStyles.Add(new RowStyle(SizeType.Absolute, 32));
                t.Controls.Add(Lbl("Head models"), 0, rows.Length); t.Controls.Add(headBox, 1, rows.Length);
                t.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); t.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
                var note = new Label { Dock = DockStyle.Fill, Text = "The template models give the skeleton (and materials for anything the suit has no textures for).\n" +
                    "The suit material is a Spider-Man 2 material on the standard suit shader (e.g. sm2suits\\MILES\\materials\\hero_spiderman_miles_encoded_tor.material):\n" +
                    "each Wolverine material is rebuilt on it with the suit's own colour, normal and gloss textures.\n" +
                    "Texture folders (several allowed, separated by ;) give real texture headers. Extracted files (laid out by asset path) and the game folder supply materials and textures the suit folder lacks.\n" +
                    "Hair cards become Spider-Man 2 strand hair using the strand settings of the hair donor (e.g. boss_kraven.model). Hair colour: leave empty to use the hair material's." };
                t.Controls.Add(note, 0, rows.Length + 1); t.SetColumnSpan(note, 3);
                var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Dock = DockStyle.Fill }; t.Controls.Add(ok, 2, rows.Length + 2); f.AcceptButton = ok;
                f.Controls.Add(t);
                if (f.ShowDialog(this) == DialogResult.OK) { foreach (var kv in boxes) conv.Set(kv.Key, kv.Value.Text.Trim()); conv.Set("heads", new[] { "auto", "keep", "skip" }[headBox.SelectedIndex]); SaveSettings(); }
            }
        }
        void LoadSettings()
        {
            try
            {
                if (!File.Exists(SettingsFile)) return;
                foreach (var line in File.ReadAllLines(SettingsFile))
                {
                    int i = line.IndexOf('='); if (i < 1) continue; string k = line.Substring(0, i), v = line.Substring(i + 1);
                    if (k == "author") authorBox.Text = v;
                    else if (k == "out" && v.Length > 0) outBox.Text = v;
                    else if (k == "peter") peterBox.Checked = v == "1";
                    else if (k == "miles") milesBox.Checked = v == "1";
                    else if (ConvertSettings.Keys.Contains(k)) conv.Set(k, v);
                }
            }
            catch (IOException) { } catch (UnauthorizedAccessException) { }
        }
        void SaveSettings()
        {
            if (Quiet) return;
            try { File.WriteAllLines(SettingsFile, new[] { "author=" + authorBox.Text, "out=" + outBox.Text, "peter=" + (peterBox.Checked ? "1" : "0"), "miles=" + (milesBox.Checked ? "1" : "0") }
                                  .Concat(ConvertSettings.Keys.Select(k => k + "=" + conv.Get(k)))); }
            catch (IOException) { } catch (UnauthorizedAccessException) { }
        }

        // ---------- adding folders
        void PickFolder()
        {
            using (var d = new FolderBrowserDialog { Description = "Folder with the suit's models, materials and textures", ShowNewFolderButton = false })
                if (d.ShowDialog(this) == DialogResult.OK) AddPath(d.SelectedPath);
        }
        /// <summary>A dropped folder, or the folder of a dropped file.</summary>
        public void AddPath(string path)
        {
            try
            {
                if (File.Exists(path)) path = Path.GetDirectoryName(path);
                if (!Directory.Exists(path)) { status.Text = "Not a folder: " + path; return; }
                path = Path.GetFullPath(path).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            }
            catch (Exception ex) { status.Text = ex.Message; return; }
            if (projects.Any(p => p.Folder.Equals(path, StringComparison.OrdinalIgnoreCase)) || toScan.Contains(path, StringComparer.OrdinalIgnoreCase)) { status.Text = "Already in the list: " + path; return; }
            toScan.Enqueue(path); ScanNext();
        }
        string scanning;
        void ScanNext()
        {
            if (scanner.IsBusy || toScan.Count == 0) { Busy(scanner.IsBusy || exporter.IsBusy); return; }
            scanning = toScan.Dequeue(); status.Text = "Reading " + scanning + " ..."; Busy(true);
            scanner.RunWorkerAsync(scanning);
        }
        void ScanDone(object s, RunWorkerCompletedEventArgs e)
        {
            if (e.Error != null) { status.Text = "Could not read " + scanning + ": " + e.Error.Message; report.Text = "Could not read " + scanning + Environment.NewLine + Environment.NewLine + e.Error; }
            else
            {
                var p = (SuitProject)e.Result;
                // two folders with the same name would otherwise write over each other
                string id = p.Id; int n = 2; while (projects.Any(x => x.Id == id)) id = p.Id + "_" + n++;
                p.SetId(id);
                projects.Add(p); status.Text = "Added " + p.Folder; RefreshList(p);
            }
            if (toScan.Count > 0) { ScanNext(); return; }
            Busy(false);
            if (AutoExport) { if (projects.Count > 0) StartExport(); else Finish(2); }
        }
        void RemoveSelected()
        {
            if (Working) return;
            foreach (ListViewItem i in list.SelectedItems) projects.Remove(i.Tag as SuitProject);
            RefreshList(null);
        }

        // ---------- showing
        void RefreshList(SuitProject select)
        {
            loading = true;
            list.BeginUpdate(); list.Items.Clear();
            foreach (var p in projects)
            {
                var it = new ListViewItem(new[] { p.SuitName, p.Folder, p.Files.Count.ToString(), Scanner.Mb(p.Files.Sum(f => f.Size)), Exporter.Status(p) }) { Tag = p };
                Tint(it, p); list.Items.Add(it); if (p == select) it.Selected = true;
            }
            if (list.SelectedItems.Count == 0 && list.Items.Count > 0) list.Items[0].Selected = true;
            list.EndUpdate(); loading = false;
            ShowSelected(); Busy(scanner.IsBusy || exporter.IsBusy);
        }
        static void Tint(ListViewItem it, SuitProject p)
        {
            it.ForeColor = Exporter.Problem(p).Length > 0 ? Color.Firebrick : p.Playable ? SystemColors.WindowText : Color.FromArgb(160, 90, 0);
        }
        void ShowSelected()
        {
            if (loading) return;
            var p = Selected; loading = true;
            detail.Enabled = p != null && !Working;
            idBox.Text = p == null ? "" : p.Id; nameBox.Text = p == null ? "" : p.SuitName; idNote.Text = "";
            Fill(mainBox, p == null ? null : p.Models, p == null ? null : p.MainModel, false);
            Fill(maskBox, p == null ? null : p.Models, p == null ? null : p.MaskModel, true);
            Fill(iconBox, p == null ? null : p.Textures, p == null ? null : p.Icon, true);
            loading = false;
            ShowReport(p);
        }
        static void Fill(ComboBox c, IEnumerable<string> items, string value, bool optional)
        {
            c.BeginUpdate(); c.Items.Clear();
            if (items != null)
            {
                if (optional) c.Items.Add(None);
                foreach (var i in items) c.Items.Add(i);
                int at = string.IsNullOrEmpty(value) ? -1 : c.Items.IndexOf(value);
                c.SelectedIndex = at >= 0 ? at : (optional ? 0 : (c.Items.Count > 0 ? 0 : -1));
            }
            c.EndUpdate();
        }
        void ShowReport(SuitProject p)
        {
            if (p != null) { report.Text = Scanner.Report(p).Replace("\r\n", "\n").Replace("\n", Environment.NewLine); return; }
            report.Text = string.Join(Environment.NewLine, new[]
            {
                "No folder yet.",
                "",
                "Drop a folder that holds one suit's files, for example  extracted\\hero\\hero_wolverine_battle :",
                "    *.model  (or *.model.0 + *.model.1)     the suit's models",
                "    *.material                              their materials",
                "    *.texture + *.hd.texture                the textures",
                "Sub-folders are included. A Suit Tool project folder (with 0\\ and 1\\ inside) works too.",
                "",
                "For every folder you get one .suit for Peter and one for Miles, ready for Overstrike, plus a report.",
                "",
                "Wolverine folders are converted on export: the wearable models are re-rigged onto Peter's and Miles's",
                "Spider-Man 2 skeletons (in Blender, with the Luna Engine IO add-on) and the textures are rewritten in the PC layout.",
                "Set Blender, the add-on and the two Spider-Man 2 template models under Conversion... (they are found automatically",
                "when they are in Downloads). Folders already in Spider-Man 2 format are packed as they are.",
            });
        }
        /// <summary>Applies a change the user made in the "Selected suit" boxes.</summary>
        void Edit(Action<SuitProject> change)
        {
            if (loading) return; var p = Selected; if (p == null) return;
            change(p);
            foreach (ListViewItem it in list.Items) if (it.Tag == p) { it.SubItems[0].Text = p.SuitName; it.SubItems[4].Text = Exporter.Status(p); Tint(it, p); }
            ShowReport(p); Busy(false);
        }
        void Busy(bool busy)
        {
            bool work = Working;
            addBtn.Enabled = removeBtn.Enabled = clearBtn.Enabled = browseBtn.Enabled = convBtn.Enabled = !work;
            authorBox.Enabled = outBox.Enabled = peterBox.Enabled = milesBox.Enabled = !work;
            detail.Enabled = !work && Selected != null;
            exportBtn.Enabled = !busy && projects.Any(p => Exporter.Problem(p).Length == 0);
            openBtn.Enabled = Directory.Exists(outBox.Text);
            UseWaitCursor = busy;
        }

        // ---------- exporting
        class Job { public List<SuitProject> Projects; public ExportOptions Options; }
        class Outcome { public List<string> Written = new List<string>(), Failed = new List<string>(); public int Suits, NotPlayable; }

        public void StartExport()
        {
            if (scanner.IsBusy || exporter.IsBusy) return;
            var o = new ExportOptions { Author = authorBox.Text.Trim(), Peter = peterBox.Checked, Miles = milesBox.Checked, ExeDir = exeDir, Convert = conv };
            if (projects.Any(p => Exporter.Problem(p).Length == 0 && !p.Playable && p.InWolverineFormat.Count > 0))
            {
                string miss = conv.Missing(o.Peter, o.Miles, exeDir);
                if (miss.Length > 0) { Say("To convert Wolverine folders, this is still needed:\n" + miss + "\n\nSet it under Conversion...", true); return; }
            }
            if (o.Heroes == 0) { Say("Tick Peter, Miles or both.", true); return; }
            try { o.OutDir = Path.GetFullPath(outBox.Text.Trim()); Directory.CreateDirectory(o.OutDir); }
            catch (Exception ex) { Say("Cannot use that folder for the suits:\n" + ex.Message, true); return; }
            var ok = projects.Where(p => Exporter.Problem(p).Length == 0).ToList();
            if (ok.Count == 0) { Say("Nothing in the list can be exported.", true); return; }
            var dup = ok.GroupBy(p => p.Id).FirstOrDefault(g => g.Count() > 1);
            if (dup != null) { Say("Two suits have the id \"" + dup.Key + "\". Give one of them another id.", true); return; }
            long need = ok.Sum(p => p.Files.Sum(f => f.Size)) * o.Heroes;
            try { var drive = new DriveInfo(Path.GetPathRoot(o.OutDir)); if (drive.AvailableFreeSpace < need) { Say("Not enough free space on " + drive.Name + " (up to " + Scanner.Mb(need) + " needed).", true); return; } }
            catch (Exception) { }     // a network path has no drive letter; the write itself will tell
            bar.Value = 0; lastExport = o.OutDir;
            exporter.RunWorkerAsync(new Job { Projects = ok, Options = o });
            Busy(true);
        }
        void ExportWork(object s, DoWorkEventArgs e)
        {
            var job = (Job)e.Argument; var res = new Outcome(); var w = (BackgroundWorker)s;
            long total = Math.Max(1, job.Projects.Sum(p => p.Files.Sum(f => f.Size))), done = 0; int last = -1;
            foreach (var p in job.Projects)
            {
                long size = p.Files.Sum(f => f.Size), before = done;
                try
                {
                    var files = Exporter.Export(p, job.Options, (frac, text) =>
                    {
                        int v = (int)(1000.0 * (before + frac * size) / total);
                        if (v != last) { last = v; w.ReportProgress(v, text); }
                    });
                    res.Written.AddRange(files); res.Suits += job.Options.Heroes; if (!p.Playable && job.Options.Convert == null) res.NotPlayable += job.Options.Heroes;
                }
                catch (Exception ex) { res.Failed.Add(p.SuitName + ": " + ex.Message); }
                done += size;
            }
            e.Result = res;
        }
        void ExportDone(object s, RunWorkerCompletedEventArgs e)
        {
            bar.Value = e.Error == null ? 1000 : 0; Busy(false);
            if (e.Error != null) { Say("Export failed:\n" + e.Error.Message, true); Finish(1); return; }
            var r = (Outcome)e.Result;
            var sb = new StringBuilder();
            sb.AppendLine(r.Suits + " .suit file" + (r.Suits == 1 ? "" : "s") + " written to " + lastExport);
            if (r.NotPlayable > 0)
            {
                sb.AppendLine();
                sb.AppendLine(r.NotPlayable + " of them " + (r.NotPlayable == 1 ? "is" : "are") + " marked NOT-PLAYABLE: the files inside are still in Marvel's Wolverine format, which Spider-Man 2 cannot load. " +
                              "The report next to each suit lists what has to be converted first.");
            }
            if (r.Failed.Count > 0) { sb.AppendLine(); sb.AppendLine("Failed:"); foreach (var f in r.Failed) sb.AppendLine("  " + f); }
            status.Text = r.Suits + " suit file" + (r.Suits == 1 ? "" : "s") + " written" + (r.NotPlayable > 0 ? " (" + r.NotPlayable + " not playable yet)" : "") + (r.Failed.Count > 0 ? ", " + r.Failed.Count + " failed" : "");
            report.Text = sb + Environment.NewLine + "Written:" + Environment.NewLine + string.Join(Environment.NewLine, r.Written.Select(x => "  " + x)) +
                          Environment.NewLine + Environment.NewLine + "----------" + Environment.NewLine + Environment.NewLine +
                          (Selected == null ? "" : Scanner.Report(Selected).Replace("\r\n", "\n").Replace("\n", Environment.NewLine));
            Say(sb.ToString().TrimEnd(), r.Failed.Count > 0 || r.NotPlayable > 0);
            Finish(r.Failed.Count > 0 ? 1 : 0);
        }
        void Say(string text, bool warn)
        {
            status.Text = text.Split('\n')[0].Trim();
            if (!Quiet) MessageBox.Show(this, text, "Suit Exporter", MessageBoxButtons.OK, warn ? MessageBoxIcon.Warning : MessageBoxIcon.Information);
        }
        void Finish(int code) { if (ExitWhenDone) { ExitCode = code; Close(); } }
        void OpenOutput()
        {
            try { if (Directory.Exists(outBox.Text)) Process.Start(new ProcessStartInfo { FileName = outBox.Text, UseShellExecute = true }); }
            catch (Exception ex) { status.Text = ex.Message; }
        }
    }

    static class Program
    {
        const string Title = "Suit Exporter";
        static string ExeDir { get { return Path.GetDirectoryName(Application.ExecutablePath); } }
        static string ErrorFile { get { return Path.Combine(ExeDir, "SuitExporter-error.txt"); } }

        static void Report(Exception ex, bool fatal)
        {
            string text = DateTime.Now + "  " + (fatal ? "could not start" : "error") + Environment.NewLine + ex + Environment.NewLine + Environment.NewLine;
            try { File.AppendAllText(ErrorFile, text); } catch (Exception) { }
            Exception inner = ex; while (inner.InnerException != null) inner = inner.InnerException;
            MessageBox.Show((fatal ? "Suit Exporter could not start:\n\n" : "Unexpected error:\n\n") + inner.GetType().Name + ": " + inner.Message +
                "\n\nDetails were written to " + ErrorFile, Title, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // Main does nothing but call Run, so that even a failure to load part of the program is caught and shown
        [STAThread]
        static int Main(string[] args)
        {
            try { return Run(args); }
            catch (Exception ex) { Report(ex, true); return 1; }
        }

        static int Run(string[] args)
        {
            if (args.Contains("--cli")) return Exporter.Cli(args, ExeDir);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
            Application.ThreadException += (s, e) => Report(e.Exception, false);
            // folders dropped on the exe itself arrive as arguments
            var form = new ExporterForm(args.Where(a => !a.StartsWith("--")).ToList());
            if (args.Contains("--export")) { form.AutoExport = true; form.Quiet = true; }
            if (args.Contains("--quiet")) form.Quiet = true;
            if (args.Contains("--exit")) form.ExitWhenDone = true;
            Application.Run(form);
            return form.ExitCode;
        }
    }
}
