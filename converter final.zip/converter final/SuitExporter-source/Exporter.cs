// Writes the .suit files and the report for scanned folders. Used by the window and by the --cli mode.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace SuitExport
{
    public class ExportOptions
    {
        public string OutDir, Author = "", ExeDir = ""; public bool Peter = true, Miles = true;
        /// <summary>When set, folders in Wolverine format are converted to Spider-Man 2 files before packing.</summary>
        public ConvertSettings Convert;
        public int Heroes { get { return (Peter ? 1 : 0) + (Miles ? 1 : 0); } }
    }

    public static class Exporter
    {
        public const string Version = "2.4";
        /// <summary>Marks the file name of a suit that still holds Wolverine-format assets.</summary>
        public const string NotPlayableMark = ".NOT-PLAYABLE";

        /// <summary>What stops a project from being written at all (empty text = nothing).</summary>
        public static string Problem(SuitProject p)
        {
            if (p.Files.Count == 0) return "No game asset files were found in this folder.";
            if (!Regex.IsMatch(p.Id ?? "", "^[a-z0-9_]{1,48}$")) return "The suit id may only have lower-case letters, digits and _ (1 to 48 characters).";
            if (string.IsNullOrWhiteSpace(p.SuitName)) return "The suit needs a name.";
            if (string.IsNullOrEmpty(p.MainModel)) return "There is no .model file to use as the suit's model.";
            return "";
        }

        public static string Status(SuitProject p)
        {
            string prob = Problem(p);
            if (prob.Length > 0) return "Cannot export: " + prob;
            int w = p.InWolverineFormat.Count;
            if (w > 0) return "Wolverine format: converted to Spider-Man 2 on export (" + w + " of " + p.Files.Count + " files)";
            return "Ready to export (no Wolverine-format files found)";
        }

        public static string FolderFor(SuitProject p, ExportOptions o) { return Path.Combine(o.OutDir, p.Id); }
        public static string FileFor(SuitProject p, ExportOptions o, bool peter)
        {
            bool both = o.Heroes == 2;
            return Path.Combine(FolderFor(p, o), p.Id + (both ? (peter ? "_peter" : "_miles") : "") + (p.Playable ? "" : NotPlayableMark) + ".suit");
        }

        /// <summary>Writes one .suit per chosen hero and a report next to them. Returns the files written.
        /// progress gets a 0..1 fraction and a line of text.</summary>
        public static List<string> Export(SuitProject p, ExportOptions o, Action<double, string> progress = null)
        {
            string prob = Problem(p); if (prob.Length > 0) throw new InvalidOperationException(prob);
            if (o.Heroes == 0) throw new InvalidOperationException("Choose at least one hero.");
            if (!p.Playable && p.InWolverineFormat.Count > 0 && o.Convert != null) return ConvertAndExport(p, o, progress);
            string dir = FolderFor(p, o); Directory.CreateDirectory(dir);
            var heroes = new List<bool>(); if (o.Peter) heroes.Add(true); if (o.Miles) heroes.Add(false);
            var written = new List<string>();
            // an earlier export of this suit under the other playable state would otherwise sit next to the new one
            foreach (bool peter in heroes)
            {
                string now = FileFor(p, o, peter);
                string other = p.Playable ? now.Substring(0, now.Length - 5) + NotPlayableMark + ".suit" : now.Replace(NotPlayableMark + ".suit", ".suit");
                if (!other.Equals(now, StringComparison.OrdinalIgnoreCase) && File.Exists(other)) try { File.Move(other, other + ".old"); } catch (IOException) { } catch (UnauthorizedAccessException) { }
            }
            for (int h = 0; h < heroes.Count; h++)
            {
                bool peter = heroes[h]; int hi = h;
                var spec = Scanner.Spec(p, peter, o.Author, heroes.Count == 2);
                string outFile = FileFor(p, o, peter), tmp = outFile + ".part";
                string label = p.SuitName + " for " + (peter ? "Peter" : "Miles");
                try
                {
                    SuitWriter.Write(tmp, spec, f => { if (progress != null) progress((hi + f) / heroes.Count, "Packing " + label + "  " + (int)(f * 100) + "%"); });
                    if (File.Exists(outFile)) File.Delete(outFile);
                    File.Move(tmp, outFile);
                }
                finally { if (File.Exists(tmp)) try { File.Delete(tmp); } catch (IOException) { } }
                written.Add(outFile + "   (" + Scanner.Mb(new FileInfo(outFile).Length) + ", suit id " + spec.Id + ", for " + (peter ? "Peter" : "Miles") + ")");
            }
            string report = Path.Combine(dir, p.Id + "_report.txt");
            File.WriteAllText(report, "Suit Exporter " + Version + " report, " + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + Environment.NewLine + Environment.NewLine +
                              Scanner.Report(p, written).Replace("\r\n", "\n").Replace("\n", Environment.NewLine));
            written.Add(report);
            return written;
        }

        /// <summary>Converts a Wolverine folder (models re-rigged onto Peter's / Miles's skeleton, textures rewritten in the
        /// PC layout) and packs one .suit per hero from the converted files.</summary>
        static List<string> ConvertAndExport(SuitProject p, ExportOptions o, Action<double, string> progress)
        {
            string miss = o.Convert.Missing(o.Peter, o.Miles, o.ExeDir);
            if (miss.Length > 0) throw new InvalidOperationException("Cannot convert to Spider-Man 2 format, missing: " + miss + ". Set them under \"Conversion...\".");
            string dir = FolderFor(p, o), work = Path.Combine(dir, "converted"); Directory.CreateDirectory(dir);
            int lines = 0;
            if (progress != null) progress(0.02, "Converting " + p.SuitName + " in Blender...");
            var folders = Converter.Run(p, o, work, l => { lines++; if (progress != null) progress(Math.Min(0.7, 0.02 + lines * 0.008), "Converting: " + l.Trim()); });
            var written = new List<string>(); var reports = new StringBuilder();
            var heroes = folders.Keys.OrderByDescending(x => x).ToList();
            for (int h = 0; h < heroes.Count; h++)
            {
                bool peter = heroes[h]; int hi = h;
                var q = Scanner.Scan(folders[peter], null);
                q.SetId(p.Id); q.SuitName = p.SuitName;
                q.MainModel = q.Models.FirstOrDefault(m => m.EndsWith("_" + (peter ? "peter" : "miles") + ".model", StringComparison.OrdinalIgnoreCase)) ?? q.MainModel;
                q.MaskModel = "";
                q.Icon = q.Textures.FirstOrDefault(t => Hashes.Normalize(t) == Hashes.Normalize(p.Icon ?? "")) ?? q.Icon;
                var spec = Scanner.Spec(q, peter, o.Author, o.Heroes == 2);
                string outFile = Path.Combine(dir, p.Id + (o.Heroes == 2 ? (peter ? "_peter" : "_miles") : "") + ".suit"), tmp = outFile + ".part";
                string old = outFile.Substring(0, outFile.Length - 5) + NotPlayableMark + ".suit";
                if (File.Exists(old)) try { File.Move(old, old + ".old"); } catch (IOException) { } catch (UnauthorizedAccessException) { }
                string label = p.SuitName + " for " + (peter ? "Peter" : "Miles");
                try
                {
                    SuitWriter.Write(tmp, spec, f => { if (progress != null) progress(0.7 + 0.3 * (hi + f) / heroes.Count, "Packing " + label + "  " + (int)(f * 100) + "%"); });
                    if (File.Exists(outFile)) File.Delete(outFile);
                    File.Move(tmp, outFile);
                }
                finally { if (File.Exists(tmp)) try { File.Delete(tmp); } catch (IOException) { } }
                written.Add(outFile + "   (" + Scanner.Mb(new FileInfo(outFile).Length) + ", suit id " + spec.Id + ", for " + (peter ? "Peter" : "Miles") + ", converted)");
                reports.AppendLine("==== " + label + " ====").AppendLine(Scanner.Report(q));
            }
            string log = Path.Combine(work, p.Id + "_convert_log.txt");
            string report = Path.Combine(dir, p.Id + "_report.txt");
            File.WriteAllText(report, ("Suit Exporter " + Version + " report, " + DateTime.Now.ToString("yyyy-MM-dd HH:mm") + "\n\n" +
                "Converted from Marvel's Wolverine format: " + p.Folder + "\n" +
                "  models    re-rigged onto the hero's Spider-Man 2 skeleton and written with the template model\n" +
                "  textures  rewritten in the PC layout (Spider-Man 2 texture headers)\n" +
                "  materials each Wolverine material rebuilt as a Spider-Man 2 suit material (hero_spiderman_suit_ggx) on the converted textures;\n" +
                "            parts with no textures of their own keep the template suit's materials (see the log)\n\n" +
                "Written:\n" + string.Join("\n", written.Select(x => "  " + x)) + "\n\n" +
                "Conversion log:\n" + (File.Exists(log) ? File.ReadAllText(log) : "(none)") + "\n" + reports).Replace("\r\n", "\n").Replace("\n", Environment.NewLine));
            written.Add(report);
            return written;
        }

        /// <summary>Command line mode: --cli folder... [--out dir] [--author name] [--heroes peter,miles] [--names hashes.txt] [--id x] [--scan]</summary>
        public static int Cli(string[] args, string exeDir)
        {
            var log = new StringBuilder(); int rc = 0;
            Action<string> say = s => { Console.WriteLine(s); log.AppendLine(s); };
            var folders = new List<string>(); var o = new ExportOptions { OutDir = Path.Combine(exeDir, "Suits"), ExeDir = exeDir };
            o.Convert = ExporterForm.LoadConvert(exeDir);
            string names = null, id = null; bool scanOnly = false;
            for (int i = 0; i < args.Length; i++)
            {
                string a = args[i]; Func<string> next = () => i + 1 < args.Length ? args[++i] : "";
                if (a == "--cli") continue;
                else if (a == "--out") o.OutDir = Path.GetFullPath(next());
                else if (a == "--author") o.Author = next();
                else if (a == "--names") names = next();
                else if (a == "--id") id = next();
                else if (a == "--scan") scanOnly = true;
                else if (a == "--no-convert") o.Convert = null;
                else if (a == "--blender") o.Convert.Blender = next();
                else if (a == "--luna") o.Convert.Luna = next();
                else if (a == "--peter-template") o.Convert.Peter = next();
                else if (a == "--sm2-material") o.Convert.Sm2Material = next();
                else if (a == "--sm2-textures") o.Convert.Sm2Textures = next();
                else if (a == "--wolverine-game") o.Convert.WolverineGame = next();
                else if (a == "--heads") o.Convert.Set("heads", next());
                else if (a == "--hair-donor") o.Convert.HairDonor = next();
                else if (a == "--extracted") o.Convert.Extracted = next();
                else if (a == "--hair-colour") o.Convert.HairColour = next();
                else if (a == "--miles-template") o.Convert.Miles = next();
                else if (a == "--heroes") { string h = next().ToLowerInvariant(); o.Peter = h.Contains("peter"); o.Miles = h.Contains("miles"); }
                else folders.Add(a);
            }
            try
            {
                if (folders.Count == 0) { say("usage: SuitExporter.exe --cli <folder>... [--out dir] [--author name] [--heroes peter,miles] [--names hashes.txt] [--id suit_id] [--scan]"); rc = 2; }
                foreach (var f in folders)
                {
                    if (!Directory.Exists(f)) { say("Not a folder: " + f); rc = 1; continue; }
                    var list = names != null ? new NameList(names) : NameList.Find(NameList.Above(Path.GetFullPath(f), 6).Concat(new[] { exeDir }).ToArray());
                    say(list == null ? "No asset name list (hashes.txt) found." : "Asset names from " + list.Source);
                    var p = Scanner.Scan(f, list);
                    if (id != null) p.SetId(id);
                    if (scanOnly) { say(Scanner.Report(p)); continue; }
                    string prob = Problem(p);
                    if (prob.Length > 0) { say(p.Folder + ": " + prob); rc = 1; continue; }
                    int last = -1;
                    var written = Export(p, o, (frac, text) => { int pc = (int)(frac * 10); if (pc != last) { last = pc; Console.WriteLine("  " + text); } });
                    say(Scanner.Report(p, written));
                }
            }
            catch (Exception ex) { say("FAILED: " + ex); rc = 1; }
            try { File.WriteAllText(Path.Combine(exeDir, "SuitExporter-cli.txt"), log.ToString()); } catch (IOException) { } catch (UnauthorizedAccessException) { }
            return rc;
        }
    }
}
